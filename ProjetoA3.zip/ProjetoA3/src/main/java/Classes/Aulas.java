package Classes;

public class Aulas {
    private String nomeProf, Materia, Conteudo, Link;
    
     public Aulas (String nomeProf, String Materia,String Conteudo, String Link) {
 
    this.nomeProf = nomeProf;
    this.Materia = Materia;
    this.Conteudo = Conteudo;
    this.Link = Link;
     }


    public String getNomeProf() {
        return nomeProf;
    }

    public void setNomeProf(String nomeProf) {
        this.nomeProf = nomeProf;
    }

    public String getMateria() {
        return Materia;
    }

    public void setMateria(String Materia) {
        this.Materia = Materia;
    }

    public String getConteudo() {
        return Conteudo;
    }

    public void setConteudo(String Conteudo) {
        this.Conteudo = Conteudo;
    }

    public String getLink() {
        return Link;
    }

    public void setLink(String Link) {
        this.Link = Link;
    }
    @Override
    public String toString() {
    return this.Materia + " - " + this.Conteudo;
}
}
