package Classes;

public class Aulas {
    private int codigo;
    private String nomeProf, Materia, Conteudo, Link;
    
    // Construtor com o código
    public Aulas(int codigo, String nomeProf, String Materia, String Conteudo, String Link) {
        this.codigo = codigo;     
        this.nomeProf = nomeProf;
        this.Materia = Materia;
        this.Conteudo = Conteudo;
        this.Link = Link;
    }

    // Construtor sem o código
    public Aulas(String nomeProf, String Materia, String Conteudo, String Link) {
        this.nomeProf = nomeProf;
        this.Materia = Materia;
        this.Conteudo = Conteudo;
        this.Link = Link;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNomeProf() {
        return nomeProf;
    }

    public void setNomeProf(String nomeProf) {
        this.nomeProf = nomeProf;
    }

    public String getMateria() {
        return Materia;
    }

    public void setMateria(String Materia) {
        this.Materia = Materia;
    }

    public String getConteudo() {
        return Conteudo;
    }

    public void setConteudo(String Conteudo) {
        this.Conteudo = Conteudo;
    }

    public String getLink() {
        return Link;
    }

    public void setLink(String Link) {
        this.Link = Link;
    }

    @Override
    public String toString() {
        return this.Materia + " - " + this.Conteudo;
    }
}