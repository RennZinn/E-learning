package Classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoBD {
    private static String host = "127.0.0.1";
    private static String porta = "3306";
    private static String db = "DB_Elearning";
    private static String user = "root";
    private static String senha = "2803";

    public static Connection obtemConexao() throws Exception {
        try {
            // Adicione o parâmetro serverTimezone à string de conexão JDBC para especificar o fuso horário
            String url = String.format("jdbc:mysql://" + host + ":" + porta + "/" + db + "?serverTimezone=UTC");
            return DriverManager.getConnection(url, user, senha);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}