import Classes.Aulas;
import Classes.DAO;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class CatalogoAula extends javax.swing.JFrame {
    private DAO dao;
    
    public CatalogoAula() {
        initComponents();
        dao = new DAO();
        configurarFiltros();
        atualizarTabelaAula();
        int red = 0;
        int green = 80;
        int blue = 117;
        Color customColor = new Color(red, green, blue);

        // Mudando a cor de fundo do content pane
        getContentPane().setBackground(customColor);
        
        // Permitir seleção de célula única
        aulaTable.setCellSelectionEnabled(true);
        aulaTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    }
        private void configurarFiltros() {
        profComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                atualizarTabelaAula();
            }
        });

        materiaComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                atualizarTabelaAula();
            }
        });
    aulaTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
    @Override
    public void valueChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting()) {
            int selectedColumn = aulaTable.getSelectedColumn();
            int selectedRow = aulaTable.getSelectedRow();
            if (selectedColumn != -1 && selectedRow != -1 && aulaTable.getColumnName(selectedColumn).equals("Link")) {
                Object selectedValue = aulaTable.getValueAt(selectedRow, selectedColumn);
                // Copia o valor da célula selecionada para a área de transferência
                StringSelection stringSelection = new StringSelection(selectedValue.toString());
                Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                clipboard.setContents(stringSelection, null);
                // Exibe a mensagem
                JOptionPane.showMessageDialog(null, "Link copiado!");
            }
        }
    }
});
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        voltarButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        aulaTable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        profComboBox = new javax.swing.JComboBox<>();
        materiaComboBox = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 700));

        voltarButton.setBackground(new java.awt.Color(114, 114, 114));
        voltarButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        voltarButton.setForeground(new java.awt.Color(255, 255, 255));
        voltarButton.setText("Voltar");
        voltarButton.setAlignmentX(0.5F);
        voltarButton.setBorderPainted(false);
        voltarButton.setContentAreaFilled(false);
        voltarButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        voltarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarButtonActionPerformed(evt);
            }
        });

        aulaTable.setBackground(new java.awt.Color(120, 120, 120));
        aulaTable.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        aulaTable.setForeground(new java.awt.Color(255, 255, 255));
        aulaTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Código", "Professor", "Matéria", "Conteúdo", "Link"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        aulaTable.setFocusable(false);
        aulaTable.setGridColor(new java.awt.Color(120, 120, 120));
        aulaTable.setSelectionBackground(new java.awt.Color(90, 90, 90));
        aulaTable.setSelectionForeground(new java.awt.Color(204, 204, 204));
        aulaTable.setShowGrid(false);
        aulaTable.setShowHorizontalLines(true);
        jScrollPane1.setViewportView(aulaTable);
        if (aulaTable.getColumnModel().getColumnCount() > 0) {
            aulaTable.getColumnModel().getColumn(0).setResizable(false);
            aulaTable.getColumnModel().getColumn(0).setPreferredWidth(50);
            aulaTable.getColumnModel().getColumn(1).setPreferredWidth(150);
            aulaTable.getColumnModel().getColumn(2).setPreferredWidth(100);
            aulaTable.getColumnModel().getColumn(3).setPreferredWidth(250);
            aulaTable.getColumnModel().getColumn(4).setMinWidth(350);
            aulaTable.getColumnModel().getColumn(4).setPreferredWidth(350);
        }

        jLabel1.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Professor");

        jLabel2.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Matéria");

        profComboBox.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        profComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mostrar tudo", "HISTORIAR-TE", "Prof Noslen", "Sandro Curió", "Gabriel Cabral", "Jeangrafia", "Português com Letícia", "Gis com Giz Matemática", "Professo Boaro", "Paulo Jubilut", "Profa Anelize", "Professora Pamba", "Samuel Cunha", "Paulo Valim", "Davi Oliveira", "Kennedy Ramos", "Ricardo Marcílio" }));
        profComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                profComboBoxActionPerformed(evt);
            }
        });

        materiaComboBox.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        materiaComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mostrar tudo", "História", "Português", "Matemática", "Química", "Geografia", "Física", "Biologia" }));
        materiaComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                materiaComboBoxActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1000, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(profComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(materiaComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(voltarButton))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(profComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(materiaComboBox, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 577, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(voltarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        setSize(new java.awt.Dimension(1016, 708));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void voltarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarButtonActionPerformed
        this.dispose(); // TODO add your handling code here:
    }//GEN-LAST:event_voltarButtonActionPerformed

    private void profComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_profComboBoxActionPerformed
        atualizarTabelaAula();
    }//GEN-LAST:event_profComboBoxActionPerformed

    private void materiaComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_materiaComboBoxActionPerformed
        atualizarTabelaAula();
    }//GEN-LAST:event_materiaComboBoxActionPerformed

    public void atualizarTabelaAula() {
        try {
            Aulas[] aula = dao.obterAulas();

            DefaultTableModel modelo = (DefaultTableModel) aulaTable.getModel();
            modelo.setRowCount(0);

            List<Aulas> aulasFiltradas = filtrarAulas(aula);
            preencherTabela(aulasFiltradas);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Aulas indisponíveis, tente novamente mais tarde.");
            e.printStackTrace();
        }
    }
    private List<Aulas> filtrarAulas(Aulas[] aulas) {
    String profSelecionado = (String) profComboBox.getSelectedItem();
    String materiaSelecionada = (String) materiaComboBox.getSelectedItem();

    List<Aulas> aulasFiltradas = new ArrayList<>(Arrays.asList(aulas));

if (!"Mostrar tudo".equals(profSelecionado) && profSelecionado != null && !profSelecionado.isEmpty()) {
    aulasFiltradas.removeIf(aula -> !aula.getNomeProf().equals(profSelecionado));
}
if (!"Mostrar tudo".equals(materiaSelecionada) && materiaSelecionada != null && !materiaSelecionada.isEmpty()) {
    aulasFiltradas.removeIf(aula -> !aula.getMateria().equals(materiaSelecionada));
}


    return aulasFiltradas;
}
    private void preencherTabela(List<Aulas> aulas) {
        DefaultTableModel modelo = (DefaultTableModel) aulaTable.getModel();
        for (Aulas aula : aulas) {
            Object[] rowData = { aula.getCodigo(), aula.getNomeProf(), aula.getMateria(), aula.getConteudo(), aula.getLink() };
            modelo.addRow(rowData);
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CatalogoAula.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CatalogoAula.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CatalogoAula.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CatalogoAula.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CatalogoAula().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable aulaTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> materiaComboBox;
    private javax.swing.JComboBox<String> profComboBox;
    private javax.swing.JButton voltarButton;
    // End of variables declaration//GEN-END:variables
}
