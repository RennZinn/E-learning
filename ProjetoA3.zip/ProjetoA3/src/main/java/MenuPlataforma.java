import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MenuPlataforma extends javax.swing.JFrame {

    /**
     * Creates new form MenuLivro
     */
    public MenuPlataforma() {
        initComponents();
        int red = 0;
        int green = 80;
        int blue = 117;
        Color customColor = new Color(red, green, blue);

        // Mudando a cor de fundo do content pane
        getContentPane().setBackground(customColor);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        gerenciarMaterialButton = new javax.swing.JButton();
        gerenciarUsuariosButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        sairButton = new javax.swing.JButton();
        verMaterialButton = new javax.swing.JButton();
        verUsuariosButton = new javax.swing.JButton();
        verAulaButton = new javax.swing.JButton();
        gerenciarAulaButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("SF Pro Display", 1, 60)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Bem-vindo a");
        jLabel1.setDoubleBuffered(true);
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        gerenciarMaterialButton.setBackground(new java.awt.Color(114, 114, 114));
        gerenciarMaterialButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        gerenciarMaterialButton.setForeground(new java.awt.Color(255, 255, 255));
        gerenciarMaterialButton.setText("Gerenciar materiais");
        gerenciarMaterialButton.setBorderPainted(false);
        gerenciarMaterialButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        gerenciarMaterialButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gerenciarMaterialButtonActionPerformed(evt);
            }
        });

        gerenciarUsuariosButton.setBackground(new java.awt.Color(114, 114, 114));
        gerenciarUsuariosButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        gerenciarUsuariosButton.setForeground(new java.awt.Color(255, 255, 255));
        gerenciarUsuariosButton.setText("Gerenciar usuários");
        gerenciarUsuariosButton.setBorderPainted(false);
        gerenciarUsuariosButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        gerenciarUsuariosButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gerenciarUsuariosButtonActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("SF Pro Display", 1, 60)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Plataforma E-Learning");

        sairButton.setBackground(new java.awt.Color(114, 114, 114));
        sairButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        sairButton.setForeground(new java.awt.Color(255, 255, 255));
        sairButton.setText("Sair");
        sairButton.setAlignmentX(0.5F);
        sairButton.setBorderPainted(false);
        sairButton.setContentAreaFilled(false);
        sairButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        sairButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairButtonActionPerformed(evt);
            }
        });

        verMaterialButton.setBackground(new java.awt.Color(114, 114, 114));
        verMaterialButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        verMaterialButton.setForeground(new java.awt.Color(255, 255, 255));
        verMaterialButton.setText("Ver materiais");
        verMaterialButton.setBorderPainted(false);
        verMaterialButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        verMaterialButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verMaterialButtonActionPerformed(evt);
            }
        });

        verUsuariosButton.setBackground(new java.awt.Color(114, 114, 114));
        verUsuariosButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        verUsuariosButton.setForeground(new java.awt.Color(255, 255, 255));
        verUsuariosButton.setText("Ver usuários");
        verUsuariosButton.setBorderPainted(false);
        verUsuariosButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        verUsuariosButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verUsuariosButtonActionPerformed(evt);
            }
        });

        verAulaButton.setBackground(new java.awt.Color(114, 114, 114));
        verAulaButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        verAulaButton.setForeground(new java.awt.Color(255, 255, 255));
        verAulaButton.setText("Ver aulas");
        verAulaButton.setBorderPainted(false);
        verAulaButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        verAulaButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verAulaButtonActionPerformed(evt);
            }
        });

        gerenciarAulaButton.setBackground(new java.awt.Color(114, 114, 114));
        gerenciarAulaButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        gerenciarAulaButton.setForeground(new java.awt.Color(255, 255, 255));
        gerenciarAulaButton.setText("Gerenciar aulas");
        gerenciarAulaButton.setBorderPainted(false);
        gerenciarAulaButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        gerenciarAulaButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gerenciarAulaButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 650, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 578, Short.MAX_VALUE)
                .addComponent(sairButton))
            .addGroup(layout.createSequentialGroup()
                .addGap(136, 136, 136)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(verMaterialButton, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(gerenciarMaterialButton, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(verAulaButton, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(verUsuariosButton, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(gerenciarUsuariosButton, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(gerenciarAulaButton, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(144, 144, 144)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(verMaterialButton, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(gerenciarMaterialButton, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(verUsuariosButton, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(gerenciarUsuariosButton, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(verAulaButton, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(gerenciarAulaButton, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 89, Short.MAX_VALUE)
                .addComponent(sairButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        setSize(new java.awt.Dimension(650, 650));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void gerenciarMaterialButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gerenciarMaterialButtonActionPerformed
        DashboardMaterial tela = new DashboardMaterial();
        tela.setLocationRelativeTo(null);
        tela.setVisible(true);
    }//GEN-LAST:event_gerenciarMaterialButtonActionPerformed

    private void gerenciarUsuariosButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gerenciarUsuariosButtonActionPerformed
        try {
            DashboardUsuarios tela = new DashboardUsuarios();
            tela.setLocationRelativeTo(null);
            tela.setVisible(true);
        } catch (Exception ex) {
            Logger.getLogger(MenuPlataforma.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_gerenciarUsuariosButtonActionPerformed

    private void sairButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairButtonActionPerformed
        this.dispose(); // TODO add your handling code here:
    }//GEN-LAST:event_sairButtonActionPerformed

    private void verMaterialButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verMaterialButtonActionPerformed
        CatalogoMaterial tela = new CatalogoMaterial();
        tela.setLocationRelativeTo(null);
        tela.setVisible(true);
    }//GEN-LAST:event_verMaterialButtonActionPerformed

    private void verUsuariosButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verUsuariosButtonActionPerformed
        CatalogoUsuarios tela = new CatalogoUsuarios();
        tela.setLocationRelativeTo(null);
        tela.setVisible(true);
    }//GEN-LAST:event_verUsuariosButtonActionPerformed

    private void verAulaButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verAulaButtonActionPerformed
        CatalogoAula tela = new CatalogoAula();
        tela.setLocationRelativeTo(null);
        tela.setVisible(true);
    }//GEN-LAST:event_verAulaButtonActionPerformed

    private void gerenciarAulaButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gerenciarAulaButtonActionPerformed
        DashboardAula tela = new DashboardAula();
        tela.setLocationRelativeTo(null);
        tela.setVisible(true);
    }//GEN-LAST:event_gerenciarAulaButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuPlataforma.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuPlataforma.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuPlataforma.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuPlataforma.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuPlataforma().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton gerenciarAulaButton;
    private javax.swing.JButton gerenciarMaterialButton;
    private javax.swing.JButton gerenciarUsuariosButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JButton sairButton;
    private javax.swing.JButton verAulaButton;
    private javax.swing.JButton verMaterialButton;
    private javax.swing.JButton verUsuariosButton;
    // End of variables declaration//GEN-END:variables
}
