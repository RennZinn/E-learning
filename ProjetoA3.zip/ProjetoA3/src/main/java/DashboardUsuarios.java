import Classes.Cadastro;
import Classes.DAO;
import javax.swing.JOptionPane;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DashboardUsuarios extends javax.swing.JFrame {

    public DashboardUsuarios() throws Exception {
        initComponents();
        buscarCadastro();
        inicializarCampos();
        setLocationRelativeTo(null);
        int red = 0;
        int green = 80;
        int blue = 117;
        Color customColor = new Color(red, green, blue);

        // Mudando a cor de fundo do content pane
        getContentPane().setBackground(customColor);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nameField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        emailField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        adressField = new javax.swing.JTextField();
        novoUsuarioButton = new javax.swing.JButton();
        removerButton = new javax.swing.JButton();
        atualizarButton = new javax.swing.JButton();
        cancelarButton = new javax.swing.JButton();
        usuarioComboBox = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        cpfField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        phoneField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        loginField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        passwordField = new javax.swing.JTextField();
        sairButton = new javax.swing.JButton();
        usuariosAtalhoButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        nameField.setBackground(new java.awt.Color(255, 255, 255));
        nameField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        nameField.setForeground(new java.awt.Color(0, 0, 0));
        nameField.setActionCommand("<Not Set>");
        nameField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        nameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameFieldActionPerformed(evt);
            }
        });
        nameField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nameFieldKeyPressed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nome");

        jLabel2.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Email");

        emailField.setBackground(new java.awt.Color(255, 255, 255));
        emailField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        emailField.setForeground(new java.awt.Color(0, 0, 0));
        emailField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        emailField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailFieldActionPerformed(evt);
            }
        });
        emailField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                emailFieldKeyReleased(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Endereço");

        adressField.setBackground(new java.awt.Color(255, 255, 255));
        adressField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        adressField.setForeground(new java.awt.Color(0, 0, 0));
        adressField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        adressField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adressFieldActionPerformed(evt);
            }
        });
        adressField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                adressFieldKeyPressed(evt);
            }
        });

        novoUsuarioButton.setBackground(new java.awt.Color(114, 114, 114));
        novoUsuarioButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        novoUsuarioButton.setForeground(new java.awt.Color(255, 255, 255));
        novoUsuarioButton.setText("Novo");
        novoUsuarioButton.setBorderPainted(false);
        novoUsuarioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                novoUsuarioButtonActionPerformed(evt);
            }
        });

        removerButton.setBackground(new java.awt.Color(114, 114, 114));
        removerButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        removerButton.setForeground(new java.awt.Color(255, 255, 255));
        removerButton.setText("Remover");
        removerButton.setBorderPainted(false);
        removerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removerButtonActionPerformed(evt);
            }
        });

        atualizarButton.setBackground(new java.awt.Color(114, 114, 114));
        atualizarButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        atualizarButton.setForeground(new java.awt.Color(255, 255, 255));
        atualizarButton.setText("Atualizar");
        atualizarButton.setBorderPainted(false);
        atualizarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atualizarButtonActionPerformed(evt);
            }
        });

        cancelarButton.setBackground(new java.awt.Color(114, 114, 114));
        cancelarButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        cancelarButton.setForeground(new java.awt.Color(255, 255, 255));
        cancelarButton.setText("Cancelar");
        cancelarButton.setBorderPainted(false);
        cancelarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarButtonActionPerformed(evt);
            }
        });

        usuarioComboBox.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        usuarioComboBox.setForeground(new java.awt.Color(255, 255, 255));
        usuarioComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usuarioComboBoxActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("CPF");

        cpfField.setBackground(new java.awt.Color(255, 255, 255));
        cpfField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        cpfField.setForeground(new java.awt.Color(0, 0, 0));
        cpfField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        cpfField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cpfFieldActionPerformed(evt);
            }
        });
        cpfField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cpfFieldKeyPressed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Telefone");

        phoneField.setBackground(new java.awt.Color(255, 255, 255));
        phoneField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        phoneField.setForeground(new java.awt.Color(0, 0, 0));
        phoneField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        phoneField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneFieldActionPerformed(evt);
            }
        });
        phoneField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                phoneFieldKeyPressed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Login");

        loginField.setBackground(new java.awt.Color(255, 255, 255));
        loginField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        loginField.setForeground(new java.awt.Color(0, 0, 0));
        loginField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        loginField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginFieldActionPerformed(evt);
            }
        });
        loginField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                loginFieldKeyPressed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Senha");

        passwordField.setBackground(new java.awt.Color(255, 255, 255));
        passwordField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        passwordField.setForeground(new java.awt.Color(0, 0, 0));
        passwordField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        passwordField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordFieldActionPerformed(evt);
            }
        });

        sairButton.setBackground(new java.awt.Color(114, 114, 114));
        sairButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        sairButton.setForeground(new java.awt.Color(255, 255, 255));
        sairButton.setText("Voltar");
        sairButton.setAlignmentX(0.5F);
        sairButton.setBorderPainted(false);
        sairButton.setContentAreaFilled(false);
        sairButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        sairButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairButtonActionPerformed(evt);
            }
        });

        usuariosAtalhoButton.setBackground(new java.awt.Color(204, 204, 204));
        usuariosAtalhoButton.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        usuariosAtalhoButton.setForeground(new java.awt.Color(204, 204, 204));
        usuariosAtalhoButton.setText("Clique aqui para ver os usuários cadastrados");
        usuariosAtalhoButton.setAlignmentX(0.5F);
        usuariosAtalhoButton.setBorderPainted(false);
        usuariosAtalhoButton.setContentAreaFilled(false);
        usuariosAtalhoButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        usuariosAtalhoButton.setMaximumSize(new java.awt.Dimension(76, 22));
        usuariosAtalhoButton.setMinimumSize(new java.awt.Dimension(76, 22));
        usuariosAtalhoButton.setPreferredSize(new java.awt.Dimension(76, 22));
        usuariosAtalhoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usuariosAtalhoButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(176, 176, 176)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel7)
                        .addGap(260, 260, 260))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(jLabel4))
                                    .addComponent(jLabel1))
                                .addGap(367, 367, 367))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(nameField, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(usuarioComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING))
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(passwordField, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(loginField, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(phoneField, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cpfField, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(adressField, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(emailField, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(novoUsuarioButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(removerButton, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE))
                                                .addGap(18, 18, 18)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(atualizarButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(cancelarButton, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)))
                                            .addComponent(usuariosAtalhoButton, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(104, 104, 104)))
                        .addComponent(sairButton))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(sairButton))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(usuarioComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1)
                        .addGap(4, 4, 4)
                        .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(emailField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(adressField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cpfField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(phoneField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(loginField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(novoUsuarioButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(atualizarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(removerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cancelarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(usuariosAtalhoButton, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private ArrayList<Cadastro> cadastros = new ArrayList<>();
    
    private boolean camposHabilitados = false;
    
    private void inicializarCampos() {
    nameField.setEditable(false);
    emailField.setEditable(false);
    adressField.setEditable(false);
    cpfField.setEditable(false);
    phoneField.setEditable(false);
    loginField.setEditable(false);
    passwordField.setEditable(false);
    }
    private void buscarCadastro() throws Exception {
    // Limpar o combo box antes de adicionar novos itens
    usuarioComboBox.removeAllItems();
    
    // Obter os cadastros do banco de dados ou de outra fonte de dados
    DAO dao = new DAO();
    ArrayList<Cadastro> cadastros = dao.obterCadastro(); // Supondo que haja um método na classe DAO para obter os cadastros
    
    // Adicionar os cadastros ao combo box
    for (Cadastro cadastro : cadastros) {
        usuarioComboBox.addItem(cadastro);
    }
}

    private void nameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameFieldActionPerformed
        setLocationRelativeTo(null);
    }//GEN-LAST:event_nameFieldActionPerformed

    private void emailFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailFieldActionPerformed
        setLocationRelativeTo(null);
    }//GEN-LAST:event_emailFieldActionPerformed

    private void adressFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adressFieldActionPerformed
        setLocationRelativeTo(null);
    }//GEN-LAST:event_adressFieldActionPerformed

    private void novoUsuarioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_novoUsuarioButtonActionPerformed
        if (!camposHabilitados) {
            // Habilitar campos e alterar texto do botão para "Confirmar"
            nameField.setEditable(true);
            emailField.setEditable(true);
            adressField.setEditable(true);
            cpfField.setEditable(true);
            phoneField.setEditable(true);
            loginField.setEditable(true);
            passwordField.setEditable(true);
            novoUsuarioButton.setText("Confirmar");
            camposHabilitados = true;
        } else {
            // Obter valores dos campos
            String nome = nameField.getText();
            String email = emailField.getText();
            String endereco = adressField.getText();
            String cpf = cpfField.getText();
            String telefone = phoneField.getText();
            String login = loginField.getText();
            String senha = passwordField.getText();

            try {
                // Verifica se os campos não estão vazios
                if (nome.isEmpty() || email.isEmpty() || endereco.isEmpty() || cpf.isEmpty() || telefone.isEmpty() || login.isEmpty() || senha.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos.");
                    return;
                }

                // Cria um novo objeto Material
                Cadastro cadastro = new Cadastro(nome, email, endereco, cpf, telefone, login, senha);

                // Chama o método cadastrarMaterial do DAO
                DAO dao = new DAO();
                if (dao.cadastrar(cadastro)) {
                    JOptionPane.showMessageDialog(null, "Usuário adicionado com sucesso!");
                    // Atualizar a lista de materiais após a adição
                    buscarCadastro();
                    CatalogoUsuarios tela = new CatalogoUsuarios();
                    tela.setLocationRelativeTo(null);
                    tela.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Erro ao adicionar usuário.");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Problemas técnicos. Tente novamente mais tarde.");
                e.printStackTrace();
            } finally {
                // Desabilitar campos e reverter texto do botão para "Novo Material"
                nameField.setEditable(false);
                emailField.setEditable(false);
                adressField.setEditable(false);
                novoUsuarioButton.setText("Novo");
                camposHabilitados = false;

                // Limpar campos
                nameField.setText("");
                emailField.setText("");
                adressField.setText("");
            }
        }
    }//GEN-LAST:event_novoUsuarioButtonActionPerformed

    private Cadastro cadastroSelecionado;
    private DAO dao = new DAO();
    
    private void removerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removerButtonActionPerformed
        if (cadastroSelecionado == null) {
            // Primeiro clique
            cadastroSelecionado = (Cadastro) usuarioComboBox.getSelectedItem();
            removerButton.setText("Confirmar Remoção");
        } else {
            // Segundo clique
            Cadastro cadastroAtual = (Cadastro) usuarioComboBox.getSelectedItem();
            if (cadastroSelecionado != null && cadastroSelecionado.equals(cadastroAtual)) {
                // Remover material selecionado
                if (dao.removerCadastro(cadastroSelecionado)) {
                    JOptionPane.showMessageDialog(null, "Usuário removido com sucesso!");
                    try {
                        // Atualizar a lista de materiais após a remoção
                        buscarCadastro();
                    } catch (Exception ex) {
                        Logger.getLogger(DashboardUsuarios.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Erro ao remover usuário.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Selecione um usuário para remover.");
            }
            // Resetar o material selecionado e o texto do botão
            cadastroSelecionado = null;
            removerButton.setText("Remover");
        }
    }//GEN-LAST:event_removerButtonActionPerformed

    private void removerCadastro(Cadastro cadastro) {
    // Implemente a lógica para remover o material, por exemplo:
    // DAO dao = new DAO();
    // dao.removerMaterial(material);
    // Atualizar a lista de materiais, se necessário
    // buscarMateriais();
}
    private void atualizarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atualizarButtonActionPerformed
        setLocationRelativeTo(null);
    }//GEN-LAST:event_atualizarButtonActionPerformed

    private void cancelarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarButtonActionPerformed
        // Desabilitar os campos textuais e limpar seus conteúdos
        nameField.setText("");
        emailField.setText("");
        adressField.setText("");
        cpfField.setText("");
        phoneField.setText("");
        loginField.setText("");
        passwordField.setText("");
        
        nameField.setEditable(false);
        emailField.setEditable(false);
        adressField.setEditable(false);
        cpfField.setEditable(false);
        phoneField.setEditable(false);
        loginField.setEditable(false);
        passwordField.setEditable(false);
        
        // Resetar o texto dos botões "Novo Material" e "Remover Material"
        novoUsuarioButton.setText("Novo");
        removerButton.setText("Remover");

        // Desabilitar os botões "Novo Material" e "Remover Material"
        novoUsuarioButton.setEnabled(true);
        removerButton.setEnabled(true);
    }//GEN-LAST:event_cancelarButtonActionPerformed

    private void usuarioComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usuarioComboBoxActionPerformed

    }//GEN-LAST:event_usuarioComboBoxActionPerformed

    private void cpfFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cpfFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cpfFieldActionPerformed

    private void phoneFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phoneFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phoneFieldActionPerformed

    private void loginFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_loginFieldActionPerformed

    private void passwordFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordFieldActionPerformed

    private void sairButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairButtonActionPerformed
         this.dispose();
    }//GEN-LAST:event_sairButtonActionPerformed

    private void usuariosAtalhoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usuariosAtalhoButtonActionPerformed
        CatalogoUsuarios tela = new CatalogoUsuarios();
        tela.setLocationRelativeTo(null);
        tela.setVisible(true);
    }//GEN-LAST:event_usuariosAtalhoButtonActionPerformed

    private void nameFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nameFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            emailField.requestFocus();
        }
    }//GEN-LAST:event_nameFieldKeyPressed

    private void emailFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_emailFieldKeyReleased
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            adressField.requestFocus();
        }
    }//GEN-LAST:event_emailFieldKeyReleased

    private void adressFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_adressFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            cpfField.requestFocus();
        }
    }//GEN-LAST:event_adressFieldKeyPressed

    private void cpfFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cpfFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            phoneField.requestFocus();
        }
    }//GEN-LAST:event_cpfFieldKeyPressed

    private void phoneFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_phoneFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            loginField.requestFocus();
        }
    }//GEN-LAST:event_phoneFieldKeyPressed

    private void loginFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_loginFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            passwordField.requestFocus();
        }
    }//GEN-LAST:event_loginFieldKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DashboardUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DashboardUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DashboardUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DashboardUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new DashboardUsuarios().setVisible(true);
                } catch (Exception ex) {
                    Logger.getLogger(DashboardUsuarios.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField adressField;
    private javax.swing.JButton atualizarButton;
    private javax.swing.JButton cancelarButton;
    private javax.swing.JTextField cpfField;
    private javax.swing.JTextField emailField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField loginField;
    private javax.swing.JTextField nameField;
    private javax.swing.JButton novoUsuarioButton;
    private javax.swing.JTextField passwordField;
    private javax.swing.JTextField phoneField;
    private javax.swing.JButton removerButton;
    private javax.swing.JButton sairButton;
    private javax.swing.JComboBox<Cadastro> usuarioComboBox;
    private javax.swing.JButton usuariosAtalhoButton;
    // End of variables declaration//GEN-END:variables

}
