import Classes.Aulas;
import Classes.DAO;
import java.awt.Color;
import java.awt.event.KeyEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

public class DashboardAula extends javax.swing.JFrame {
  
    public DashboardAula() {
        initComponents();
        buscarAulas();
        inicializarCampos();
        setLocationRelativeTo(null);
        int red = 0;
        int green = 80;
        int blue = 117;
        Color customColor = new Color(red, green, blue);

        // Mudando a cor de fundo do content pane
        getContentPane().setBackground(customColor);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        contField = new javax.swing.JTextField();
        listaAtalhoButton = new javax.swing.JButton();
        linkField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        novoButton = new javax.swing.JButton();
        atualizarButton = new javax.swing.JButton();
        removerButton = new javax.swing.JButton();
        cancelarButton = new javax.swing.JButton();
        aulaComboBox = new javax.swing.JComboBox<>();
        sairButton = new javax.swing.JButton();
        matField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        profField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        contField.setBackground(new java.awt.Color(255, 255, 255));
        contField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        contField.setForeground(new java.awt.Color(0, 0, 0));
        contField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        contField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contFieldActionPerformed(evt);
            }
        });

        listaAtalhoButton.setBackground(new java.awt.Color(204, 204, 204));
        listaAtalhoButton.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        listaAtalhoButton.setForeground(new java.awt.Color(204, 204, 204));
        listaAtalhoButton.setText("Clique aqui para ver as aulas cadastradas");
        listaAtalhoButton.setAlignmentX(0.5F);
        listaAtalhoButton.setBorderPainted(false);
        listaAtalhoButton.setContentAreaFilled(false);
        listaAtalhoButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        listaAtalhoButton.setMaximumSize(new java.awt.Dimension(76, 22));
        listaAtalhoButton.setMinimumSize(new java.awt.Dimension(76, 22));
        listaAtalhoButton.setPreferredSize(new java.awt.Dimension(76, 22));
        listaAtalhoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listaAtalhoButtonActionPerformed(evt);
            }
        });

        linkField.setBackground(new java.awt.Color(255, 255, 255));
        linkField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        linkField.setForeground(new java.awt.Color(0, 0, 0));
        linkField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        linkField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                linkFieldActionPerformed(evt);
            }
        });
        linkField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                linkFieldKeyPressed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Matéria");

        jLabel2.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Conteúdo");

        jLabel3.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Link");

        novoButton.setBackground(new java.awt.Color(114, 114, 114));
        novoButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        novoButton.setForeground(new java.awt.Color(255, 255, 255));
        novoButton.setText("Novo");
        novoButton.setBorderPainted(false);
        novoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                novoButtonActionPerformed(evt);
            }
        });

        atualizarButton.setBackground(new java.awt.Color(114, 114, 114));
        atualizarButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        atualizarButton.setForeground(new java.awt.Color(255, 255, 255));
        atualizarButton.setText("Atualizar");
        atualizarButton.setBorderPainted(false);
        atualizarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atualizarButtonActionPerformed(evt);
            }
        });

        removerButton.setBackground(new java.awt.Color(114, 114, 114));
        removerButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        removerButton.setForeground(new java.awt.Color(255, 255, 255));
        removerButton.setText("Remover");
        removerButton.setBorderPainted(false);
        removerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removerButtonActionPerformed(evt);
            }
        });

        cancelarButton.setBackground(new java.awt.Color(114, 114, 114));
        cancelarButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        cancelarButton.setForeground(new java.awt.Color(255, 255, 255));
        cancelarButton.setText("Cancelar");
        cancelarButton.setBorderPainted(false);
        cancelarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarButtonActionPerformed(evt);
            }
        });

        aulaComboBox.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        aulaComboBox.setForeground(new java.awt.Color(255, 255, 255));
        aulaComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aulaComboBoxActionPerformed(evt);
            }
        });

        sairButton.setBackground(new java.awt.Color(114, 114, 114));
        sairButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        sairButton.setForeground(new java.awt.Color(255, 255, 255));
        sairButton.setText("Voltar");
        sairButton.setAlignmentX(0.5F);
        sairButton.setBorderPainted(false);
        sairButton.setContentAreaFilled(false);
        sairButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        sairButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairButtonActionPerformed(evt);
            }
        });

        matField.setBackground(new java.awt.Color(255, 255, 255));
        matField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        matField.setForeground(new java.awt.Color(0, 0, 0));
        matField.setActionCommand("<Not Set>");
        matField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        matField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                matFieldActionPerformed(evt);
            }
        });
        matField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                matFieldKeyPressed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Professor");

        profField.setBackground(new java.awt.Color(255, 255, 255));
        profField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        profField.setForeground(new java.awt.Color(0, 0, 0));
        profField.setActionCommand("<Not Set>");
        profField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        profField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                profFieldActionPerformed(evt);
            }
        });
        profField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                profFieldKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(172, 172, 172)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(listaAtalhoButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4)
                    .addComponent(profField)
                    .addComponent(jLabel1)
                    .addComponent(matField)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel3))
                    .addComponent(linkField, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(novoButton, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(atualizarButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(aulaComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(removerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cancelarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(contField))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 108, Short.MAX_VALUE)
                .addComponent(sairButton))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addComponent(aulaComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addGap(4, 4, 4)
                .addComponent(profField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(5, 5, 5)
                .addComponent(matField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(contField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(linkField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(novoButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(atualizarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(removerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cancelarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 90, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sairButton)
                    .addComponent(listaAtalhoButton, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        setSize(new java.awt.Dimension(666, 658));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
       
       private boolean camposHabilitados = false;
       
       private void inicializarCampos() {
       profField.setEditable(false);
       matField.setEditable(false);
       contField.setEditable(false);
       linkField.setEditable(false);
      }
    private void contFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contFieldActionPerformed
        setLocationRelativeTo(null);
    }//GEN-LAST:event_contFieldActionPerformed

    private void listaAtalhoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listaAtalhoButtonActionPerformed
        CatalogoAula tela = new CatalogoAula();
        tela.setLocationRelativeTo(null);
        tela.setVisible(true);
    }//GEN-LAST:event_listaAtalhoButtonActionPerformed

    private void linkFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_linkFieldActionPerformed
        setLocationRelativeTo(null);
    }//GEN-LAST:event_linkFieldActionPerformed

    private void novoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_novoButtonActionPerformed
        if (!camposHabilitados) {
        // Habilitar campos e alterar texto do botão para "Confirmar"
        profField.setEditable(true);
        matField.setEditable(true);
        contField.setEditable(true);
        linkField.setEditable(true);
        novoButton.setText("Confirmar");
        camposHabilitados = true;
    } else {
        // Obter valores dos campos
        String nomeProf = profField.getText();
        String Materia = matField.getText();
        String Conteudo = contField.getText();
        String Link = linkField.getText();
        
        try {
            // Verifica se os campos não estão vazios
            if (nomeProf.isEmpty() || Materia.isEmpty() || Conteudo.isEmpty()|| Link.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos.");
                return;
            }
            
            // Cria um novo objeto Material
            Aulas aula = new Aulas(nomeProf, Materia, Conteudo, Link);
            
            // Chama o método cadastrarMaterial do DAO
            DAO dao = new DAO();
            if (dao.cadastrarAula(aula)) {
                JOptionPane.showMessageDialog(null, "Video adicionado com sucesso!");
                // Atualizar a lista de materiais após a adição
                buscarAulas();
                CatalogoAula tela = new CatalogoAula();
                tela.setLocationRelativeTo(null);
                tela.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "Erro ao adicionar Video.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Problemas técnicos. Tente novamente mais tarde.");
            e.printStackTrace();
        } finally {
            // Desabilitar campos e reverter texto do botão para "Novo Material"
            profField.setEditable(false);
            matField.setEditable(false);
            contField.setEditable(false);
            linkField.setEditable(false);
            novoButton.setText("Novo");
            camposHabilitados = false;

            // Limpar campos
            profField.setText("");
            matField.setText("");
            contField.setText("");
        }
    }//GEN-LAST:event_novoButtonActionPerformed
    }
    private void atualizarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atualizarButtonActionPerformed
        setLocationRelativeTo(null);
    }//GEN-LAST:event_atualizarButtonActionPerformed

    private Aulas aulaSelecionado;
       private DAO dao = new DAO();
       
    private void removerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removerButtonActionPerformed
        if (aulaSelecionado == null) {
        // Primeiro clique
        aulaSelecionado = (Aulas) aulaComboBox.getSelectedItem();
        removerButton.setText("Confirmar Remoção (1 clique)");
    } else {
        // Segundo clique
        Aulas materialAtual = (Aulas) aulaComboBox.getSelectedItem();
        if (aulaSelecionado != null && aulaSelecionado.equals(materialAtual)) {
            // Remover material selecionado
            if (dao.removerAula(aulaSelecionado)) {
                JOptionPane.showMessageDialog(null, "Video removido com sucesso!");
                CatalogoAula tela = new CatalogoAula();
                tela.setLocationRelativeTo(null);
                tela.setVisible(true);
                // Atualizar a lista de materiais após a remoção
                buscarAulas();
            } else {
                JOptionPane.showMessageDialog(null, "Erro ao remover video.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Selecione um material para video.");
        }
        // Resetar o material selecionado e o texto do botão
        aulaSelecionado = null;
        removerButton.setText("Remover");
    }  
    }//GEN-LAST:event_removerButtonActionPerformed

    private void cancelarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarButtonActionPerformed
    profField.setText("");
    matField.setText("");
    contField.setText("");
    linkField.setText("");
    profField.setEditable(false);
    matField.setEditable(false);
    contField.setEditable(false);
    linkField.setEditable(false);
    
    // Resetar o texto dos botões "Novo Material" e "Remover Material"
    novoButton.setText("Novo");
    removerButton.setText("Remover");
    
    // Desabilitar os botões "Novo Material" e "Remover Material"
    novoButton.setEnabled(true);
    removerButton.setEnabled(true);
    }//GEN-LAST:event_cancelarButtonActionPerformed

    private void buscarAulas() {
        try {
        DAO dao = new DAO();
        Aulas[] aula = dao.obterAulas();
        aulaComboBox.setModel(new DefaultComboBoxModel<>(aula));
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Aulas indisponíveis, tente novamente mais tarde.");
        e.printStackTrace();
    }
}
    
    private void aulaComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aulaComboBoxActionPerformed

    }//GEN-LAST:event_aulaComboBoxActionPerformed

    private void sairButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairButtonActionPerformed
        this.dispose();
    }//GEN-LAST:event_sairButtonActionPerformed

    private void matFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_matFieldActionPerformed
        setLocationRelativeTo(null);
    }//GEN-LAST:event_matFieldActionPerformed

    private void profFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_profFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_profFieldActionPerformed

    private void profFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_profFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            matField.requestFocus();
        }
    }//GEN-LAST:event_profFieldKeyPressed

    private void matFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_matFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            contField.requestFocus();
        }
    }//GEN-LAST:event_matFieldKeyPressed

    private void linkFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_linkFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            linkField.requestFocus();
        }
    }//GEN-LAST:event_linkFieldKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DashboardAula.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DashboardAula.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DashboardAula.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DashboardAula.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DashboardAula().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton atualizarButton;
    private javax.swing.JComboBox<Aulas> aulaComboBox;
    private javax.swing.JButton cancelarButton;
    private javax.swing.JTextField contField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField linkField;
    private javax.swing.JButton listaAtalhoButton;
    private javax.swing.JTextField matField;
    private javax.swing.JButton novoButton;
    private javax.swing.JTextField profField;
    private javax.swing.JButton removerButton;
    private javax.swing.JButton sairButton;
    // End of variables declaration//GEN-END:variables
}


