package Classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class Pessoa {
    private String nome, email, endereco, cpf, telefone, login, senha;

    // getters e setters para as propriedades
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void inserir() {
        // Definir o comando SQL
        String sql = "INSERT INTO TbUsuario(nome, email, endereco, cpf, telefone, login, senha) VALUES (?, ?, ?, ?, ?, ?, ?)";

        // Abrir uma conexão
        ConnectionFactory factory = new ConnectionFactory();
        try (Connection c = factory.obtemConexao()) {
            // Pré compila o comando
            PreparedStatement ps = c.prepareStatement(sql);

            // Preenche os dados faltantes
            ps.setString(1, nome);
            ps.setString(2, email);
            ps.setString(3, endereco);
            ps.setString(4, cpf);
            ps.setString(5, telefone);
            ps.setString(6, login);
            ps.setString(7, senha);

            // Executa o comando
            ps.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void atualizar() {
        // Definir o comando SQL
        String sql = "UPDATE TbUsuario SET nome = ?, email = ?, endereco = ?, cpf = ?, telefone = ?, login = ?, senha = ? WHERE login = ?";

        // Abrir uma conexão
        ConnectionFactory factory = new ConnectionFactory();
        try (Connection c = factory.obtemConexao()) {
            // Pré compila o comando
            PreparedStatement ps = c.prepareStatement(sql);

            // Preenche os dados faltantes
            ps.setString(1, nome);
            ps.setString(2, email);
            ps.setString(3, endereco);
            ps.setString(4, cpf);
            ps.setString(5, telefone);
            ps.setString(6, login);
            ps.setString(7, senha);

            // Executa o comando
            ps.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void apagar() {
        // Definir o comando SQL
        String sql = "DELETE FROM TbUsuario WHERE login = ?";

        // Abrir uma conexão
        ConnectionFactory factory = new ConnectionFactory();
        try (Connection c = factory.obtemConexao()) {
            // Pré compila o comando
            PreparedStatement ps = c.prepareStatement(sql);

            // Preenche os dados faltantes
            ps.setString(1, login);

            // Executa o comando
            ps.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void listar() {
        // Definir o comando SQL
        String sql = "SELECT * FROM TbUsuario";

        // Abrir uma conexão
        ConnectionFactory factory = new ConnectionFactory();
        try (Connection c = factory.obtemConexao()) {
            // Pré compila o comando
            PreparedStatement ps = c.prepareStatement(sql);

            // Executa o comando e guarda o resultado em um ResultSet
            ResultSet rs = ps.executeQuery();

            // Itera sobre o resultado
            while (rs.next()) {
                String nome = rs.getString("nome");
                String email = rs.getString("email");
                String endereco = rs.getString("endereco");
                String cpf = rs.getString("cpf");
                String telefone = rs.getString("telefone");
                String login = rs.getString("login");
                String senha = rs.getString("senha");
                String aux = String.format(
                        "Nome: %s, Email: %s, Endereço: %s, CPF: %s, Telefone: %s, Login: %s, Senha: %s",
                        nome,
                        email,
                        endereco,
                        cpf,
                        telefone,
                        login,
                        senha
                );
                JOptionPane.showMessageDialog(null, aux);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
