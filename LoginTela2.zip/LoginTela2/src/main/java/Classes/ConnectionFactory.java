package Classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.TimeZone;

public class ConnectionFactory {
    private String user = "root";
    private String senha = "2803";
    private String host = "127.0.0.1";
    private String porta = "3306";
    private String bd = "BdElearning";

    public Connection obtemConexao() {
        try {
            // Definir o fuso horário padrão antes de criar a conexão com o banco de dados
            TimeZone.setDefault(TimeZone.getTimeZone("UTC"));

            Connection c = DriverManager.getConnection(
                    "jdbc:mysql://" + host + ":" + porta + "/" + bd + "?serverTimezone=UTC", user, senha);
            return c;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
