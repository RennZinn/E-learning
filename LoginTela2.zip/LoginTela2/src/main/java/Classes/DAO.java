package Classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class DAO {
 public boolean existe (Usuario usuario) throws Exception{
 String sql = "SELECT * FROM CadastroUsuarios WHERE login = ? AND senha = ?";
 try (Connection c = ConexaoBD.obtemConexao();
 PreparedStatement ps = c.prepareStatement(sql)){
 ps.setString(1, usuario.getLogin());
 ps.setString(2, usuario.getSenha());
 try (ResultSet rs = ps.executeQuery()){
 return rs.next();
 }
 }
 }
 public boolean cadastrar(Cadastro cadastro) throws Exception {
    String sql = "INSERT INTO CadastroUsuarios (nome, email, endereco, cpf, telefone, login, senha) VALUES (?, ?, ?, ?, ?, ?, ?)";
    try (Connection c = ConexaoBD.obtemConexao();
         PreparedStatement ps = c.prepareStatement(sql)) {
        ps.setString(1, cadastro.getNome());
        ps.setString(2, cadastro.getEmail());
        ps.setString(3, cadastro.getEndereco());
        ps.setString(4, cadastro.getCpf());
        ps.setString(5, cadastro.getTelefone());
        ps.setString(6, cadastro.getLogin());
        ps.setString(7, cadastro.getSenha());
        int rowsAffected = ps.executeUpdate();
        return rowsAffected > 0; // Retorna true se o cadastro foi bem-sucedido
    }
}
}
