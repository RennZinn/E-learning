package Classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
public class DAO {
 public boolean existe (Usuario usuario) throws Exception{
 String sql = "SELECT * FROM CadastroUsuarios WHERE login = ? AND senha = ?";
 try (Connection c = ConexaoBD.obtemConexao();
 PreparedStatement ps = c.prepareStatement(sql)){
 ps.setString(1, usuario.getLogin());
 ps.setString(2, usuario.getSenha());
 try (ResultSet rs = ps.executeQuery()){
 return rs.next();
 }
 }
 }
 public boolean cadastrar(Cadastro cadastro) throws Exception {
    String sql = "INSERT INTO CadastroUsuarios (nome, email, endereco, cpf, telefone, login, senha) VALUES (?, ?, ?, ?, ?, ?, ?)";
    try (Connection c = ConexaoBD.obtemConexao();
         PreparedStatement ps = c.prepareStatement(sql)) {
        ps.setString(1, cadastro.getNome());
        ps.setString(2, cadastro.getEmail());
        ps.setString(3, cadastro.getEndereco());
        ps.setString(4, cadastro.getCpf());
        ps.setString(5, cadastro.getTelefone());
        ps.setString(6, cadastro.getLogin());
        ps.setString(7, cadastro.getSenha());
        int rowsAffected = ps.executeUpdate();
        return rowsAffected > 0; // Retorna true se o cadastro foi bem-sucedido
    }
}
 public boolean cadastrarMaterial(Material cadastro) throws Exception {
    String sql = "INSERT INTO CadastroMaterial (nome, genero, autor) VALUES (?, ?, ?)";
    try (Connection c = ConexaoBD.obtemConexao();
         PreparedStatement ps = c.prepareStatement(sql)) {
        ps.setString(1, cadastro.getNome());
        ps.setString(2, cadastro.getGenero());
        ps.setString(3, cadastro.getAutor());
        int rowsAffected = ps.executeUpdate();
        return rowsAffected > 0; // Retorna true se o cadastro foi bem-sucedido
    }
 }
 public Material[] obterMateriais() throws Exception {
    String sql = "SELECT * FROM CadastroMaterial";
    try (Connection conn = ConexaoBD.obtemConexao();
         PreparedStatement ps = conn.prepareStatement(sql,
                 ResultSet.TYPE_SCROLL_INSENSITIVE,
                 ResultSet.CONCUR_READ_ONLY);
         ResultSet rs = ps.executeQuery()) {

        int totalDeMateriais = rs.last() ? rs.getRow() : 0;
        System.out.println("Total de materiais encontrados: " + totalDeMateriais);

        Material[] materiais = new Material[totalDeMateriais];
        rs.beforeFirst();
        int contador = 0;
        while (rs.next()) {
            String nome = rs.getString("nome");
            String genero = rs.getString("genero");
            String autor = rs.getString("autor");
            materiais[contador++] = new Material(nome, genero, autor);
        }
        System.out.println("Materiais retornados: " + Arrays.toString(materiais));
        return materiais;
    }
}
public boolean removerMaterial(Material material) {
    String sql = "DELETE FROM CadastroMaterial WHERE nome = ? AND genero = ? AND autor = ?";
    try (Connection conn = ConexaoBD.obtemConexao();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, material.getNome());
        ps.setString(2, material.getGenero());
        ps.setString(3, material.getAutor());
        int rowsAffected = ps.executeUpdate();
        return rowsAffected > 0;
    } catch (Exception e) {
        System.err.println("Erro ao remover material do banco de dados: " + e.getMessage());
        return false;
    }
}
    public Aulas[] obterAulas() throws Exception {
    String sql = "SELECT * FROM Aula";
    try (Connection conn = ConexaoBD.obtemConexao();
         PreparedStatement ps = conn.prepareStatement(sql,
                 ResultSet.TYPE_SCROLL_INSENSITIVE,
                 ResultSet.CONCUR_READ_ONLY);
         ResultSet rs = ps.executeQuery()) {

        int totalDeAulas = rs.last() ? rs.getRow() : 0;
        System.out.println("Total de aulas encontradas: " + totalDeAulas);

        Aulas[] aula = new Aulas[totalDeAulas];
        rs.beforeFirst();
        int contador = 0;
        while (rs.next()) {
            String nomeProf = rs.getString("nomeProf");
            String Materia = rs.getString("Materia");
            String Conteudo = rs.getString("Conteudo");
            String Link = rs.getString("Link");
            aula[contador++] = new Aulas(nomeProf, Materia, Conteudo, Link);
        }
        System.out.println("Aulas retornadas: " + Arrays.toString(aula));
        return aula;
    }

    
}
/**
     *
     * @param aula
     * @return
     * @throws Exception
     */

    /**
     *
     * @param aula
     * @param aula
     * @return
     * @throws Exception
     */
    public boolean cadastrarAula(Aulas aula) throws Exception {
    String sql = "INSERT INTO Aula (nomeProf, Materia, Conteudo, Link) VALUES (?, ?, ?, ?)";
    try (Connection c = ConexaoBD.obtemConexao();
         PreparedStatement ps = c.prepareStatement(sql)) {
        ps.setString(1, aula.getNomeProf());
        ps.setString(2, aula.getMateria());
        ps.setString(3, aula.getConteudo());
          ps.setString(4, aula.getLink());
        int rowsAffected = ps.executeUpdate();
        return rowsAffected > 0; // Retorna true se o cadastro foi bem-sucedido
    }
}
    public boolean removerAula(Aulas aula) {
    String sql = "DELETE FROM Aula WHERE nomeProf = ? AND Materia = ? AND Conteudo = ? AND Link = ?";
    try (Connection conn = ConexaoBD.obtemConexao();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, aula.getNomeProf());
        ps.setString(2, aula.getMateria());
        ps.setString(3, aula.getConteudo());
          ps.setString(4, aula.getLink());
        int rowsAffected = ps.executeUpdate();
        return rowsAffected > 0;
    } catch (Exception e) {
        System.err.println("Erro ao remover video do banco de dados: " + e.getMessage());
        return false;
    }
}
}



