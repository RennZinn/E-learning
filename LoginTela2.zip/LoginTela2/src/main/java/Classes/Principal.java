package Classes;

import javax.swing.JOptionPane;

public class Principal {
    public static void main(String[] args) {
        String menu = "1-Cadastrar\n2-Atualizar\n3-Apagar\n4-Listar\n0-Sair";
        int op;
        do {
            try {
                op = Integer.parseInt(JOptionPane.showInputDialog(menu));
                switch (op) {
                    case 1 -> cadastrar();
                    case 2 -> atualizar();
                    case 3 -> apagar();
                    case 4 -> listar();
                    case 0 -> {
                    }
                    default -> JOptionPane.showMessageDialog(null, "Opção inválida");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, digite um número válido.");
                op = -1; // Define op como -1 para continuar no loop do-while
            }
        } while (op != 0);
    }

    private static void cadastrar() {
        try {
            String nome = JOptionPane.showInputDialog("Nome?");
            String email = JOptionPane.showInputDialog("Email?");
            String endereco = JOptionPane.showInputDialog("Endereço?");
            String cpf = JOptionPane.showInputDialog("CPF?");
            String telefone = JOptionPane.showInputDialog("Telefone?");
            String login = JOptionPane.showInputDialog("Login?");
            String senha = JOptionPane.showInputDialog("Senha?");
            
            Pessoa p = new Pessoa();
            p.setNome(nome);
            p.setEmail(email);
            p.setEndereco(endereco);
            p.setCpf(cpf);
            p.setTelefone(telefone);
            p.setLogin(login);
            p.setSenha(senha);
            p.inserir();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar: " + e.getMessage());
        }
    }

    private static void atualizar() {
        try {
            String login = JOptionPane.showInputDialog("Login?");
            String senha = JOptionPane.showInputDialog("Nova Senha?");
            
            Pessoa p = new Pessoa();
            p.setLogin(login);
            p.setSenha(senha);
            p.atualizar();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + e.getMessage());
        }
    }

    private static void apagar() {
        try {
            String cpf = JOptionPane.showInputDialog("CPF?");
            
            Pessoa p = new Pessoa();
            p.setCpf(cpf);
            p.apagar();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao apagar: " + e.getMessage());
        }
    }

    private static void listar() {
        try {
            Pessoa p = new Pessoa();
            p.listar();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar: " + e.getMessage());
        }
    }
}
