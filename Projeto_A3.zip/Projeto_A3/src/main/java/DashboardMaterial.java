import Classes.Material;
import Classes.DAO;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class DashboardMaterial extends javax.swing.JFrame {

    public DashboardMaterial() throws Exception {
        initComponents();
        buscarMateriais();
        setLocationRelativeTo(null);
        int red = 0;
        int green = 80;
        int blue = 117;
        Color customColor = new Color(red, green, blue);

        // Mudando a cor de fundo do content pane
        getContentPane().setBackground(customColor);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nameField = new javax.swing.JTextField();
        generoField = new javax.swing.JTextField();
        autorField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        novoMaterialButton = new javax.swing.JButton();
        atualizarButton = new javax.swing.JButton();
        removerButton = new javax.swing.JButton();
        cancelarButton = new javax.swing.JButton();
        materialComboBox = new javax.swing.JComboBox<>();
        sairButton = new javax.swing.JButton();
        listaAtalhoButton = new javax.swing.JButton();
        codigoField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Materiais");

        nameField.setBackground(new java.awt.Color(255, 255, 255));
        nameField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        nameField.setForeground(new java.awt.Color(0, 0, 0));
        nameField.setActionCommand("<Not Set>");
        nameField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        nameField.setMaximumSize(new java.awt.Dimension(298, 35));
        nameField.setMinimumSize(new java.awt.Dimension(298, 35));
        nameField.setPreferredSize(new java.awt.Dimension(298, 35));
        nameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameFieldActionPerformed(evt);
            }
        });
        nameField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nameFieldKeyPressed(evt);
            }
        });

        generoField.setBackground(new java.awt.Color(255, 255, 255));
        generoField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        generoField.setForeground(new java.awt.Color(0, 0, 0));
        generoField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        generoField.setMaximumSize(new java.awt.Dimension(298, 35));
        generoField.setMinimumSize(new java.awt.Dimension(298, 35));
        generoField.setPreferredSize(new java.awt.Dimension(298, 35));
        generoField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generoFieldActionPerformed(evt);
            }
        });
        generoField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                generoFieldKeyPressed(evt);
            }
        });

        autorField.setBackground(new java.awt.Color(255, 255, 255));
        autorField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        autorField.setForeground(new java.awt.Color(0, 0, 0));
        autorField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        autorField.setMaximumSize(new java.awt.Dimension(298, 35));
        autorField.setMinimumSize(new java.awt.Dimension(298, 35));
        autorField.setPreferredSize(new java.awt.Dimension(298, 35));
        autorField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                autorFieldActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nome*");

        jLabel2.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Gênero*");

        jLabel3.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Autor*");

        novoMaterialButton.setBackground(new java.awt.Color(114, 114, 114));
        novoMaterialButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        novoMaterialButton.setForeground(new java.awt.Color(255, 255, 255));
        novoMaterialButton.setText("Novo");
        novoMaterialButton.setBorderPainted(false);
        novoMaterialButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                novoMaterialButtonActionPerformed(evt);
            }
        });

        atualizarButton.setBackground(new java.awt.Color(114, 114, 114));
        atualizarButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        atualizarButton.setForeground(new java.awt.Color(255, 255, 255));
        atualizarButton.setText("Atualizar");
        atualizarButton.setBorderPainted(false);
        atualizarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atualizarButtonActionPerformed(evt);
            }
        });

        removerButton.setBackground(new java.awt.Color(114, 114, 114));
        removerButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        removerButton.setForeground(new java.awt.Color(255, 255, 255));
        removerButton.setText("Remover");
        removerButton.setBorderPainted(false);
        removerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removerButtonActionPerformed(evt);
            }
        });

        cancelarButton.setBackground(new java.awt.Color(114, 114, 114));
        cancelarButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        cancelarButton.setForeground(new java.awt.Color(255, 255, 255));
        cancelarButton.setText("Cancelar");
        cancelarButton.setBorderPainted(false);
        cancelarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarButtonActionPerformed(evt);
            }
        });

        materialComboBox.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        materialComboBox.setForeground(new java.awt.Color(255, 255, 255));
        materialComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                materialComboBoxActionPerformed(evt);
            }
        });

        sairButton.setBackground(new java.awt.Color(114, 114, 114));
        sairButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        sairButton.setForeground(new java.awt.Color(255, 255, 255));
        sairButton.setText("Voltar");
        sairButton.setAlignmentX(0.5F);
        sairButton.setBorderPainted(false);
        sairButton.setContentAreaFilled(false);
        sairButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        sairButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairButtonActionPerformed(evt);
            }
        });

        listaAtalhoButton.setBackground(new java.awt.Color(204, 204, 204));
        listaAtalhoButton.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        listaAtalhoButton.setForeground(new java.awt.Color(204, 204, 204));
        listaAtalhoButton.setText("Clique aqui para ver os materiais cadastrados");
        listaAtalhoButton.setAlignmentX(0.5F);
        listaAtalhoButton.setBorderPainted(false);
        listaAtalhoButton.setContentAreaFilled(false);
        listaAtalhoButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        listaAtalhoButton.setMaximumSize(new java.awt.Dimension(76, 22));
        listaAtalhoButton.setMinimumSize(new java.awt.Dimension(76, 22));
        listaAtalhoButton.setPreferredSize(new java.awt.Dimension(76, 22));
        listaAtalhoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listaAtalhoButtonActionPerformed(evt);
            }
        });

        codigoField.setBackground(new java.awt.Color(255, 255, 255));
        codigoField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        codigoField.setForeground(new java.awt.Color(0, 0, 0));
        codigoField.setActionCommand("<Not Set>");
        codigoField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        codigoField.setMaximumSize(new java.awt.Dimension(298, 35));
        codigoField.setMinimumSize(new java.awt.Dimension(298, 35));
        codigoField.setPreferredSize(new java.awt.Dimension(298, 35));
        codigoField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codigoFieldActionPerformed(evt);
            }
        });
        codigoField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                codigoFieldKeyPressed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Código");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(175, 175, 175)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(cancelarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.CENTER, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                        .addComponent(materialComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                .addComponent(generoField, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(autorField, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(codigoField, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel1)
                                    .addGap(257, 257, 257))
                                .addComponent(nameField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(novoMaterialButton, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(atualizarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.CENTER, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(removerButton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(listaAtalhoButton, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(105, 105, 105)
                .addComponent(sairButton))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(materialComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(codigoField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1)
                .addGap(4, 4, 4)
                .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(generoField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(autorField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(atualizarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(novoMaterialButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(removerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cancelarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 78, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sairButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(listaAtalhoButton, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        setSize(new java.awt.Dimension(666, 658));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    private ArrayList<Material> materiais = new ArrayList<>();
    
    private void buscarMateriais() throws Exception {
    // Limpar o combo box antes de adicionar novos itens
    materialComboBox.removeAllItems();
    
    // Obter os cadastros do banco de dados ou de outra fonte de dados
    DAO dao = new DAO();
    Material[] materiais = dao.obterMateriais(); // Supondo que haja um método na classe DAO para obter os cadastros
    
    // Adicionar os cadastros ao combo box
    for (Material material : materiais) {
        materialComboBox.addItem(material);
    }
}
    
    private boolean novo = true;
    
    private void novoMaterialButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_novoMaterialButtonActionPerformed
        if (novo) {
        novoMaterialButton.setText("Confirmar");
        
        // Limpar campos
        codigoField.setText("");
        nameField.setText("");
        generoField.setText("");
        autorField.setText("");
        
        novo = false;
    } else {
        try {
            String codigoText = codigoField.getText();
            String nome = nameField.getText();
            String genero = generoField.getText();
            String autor = autorField.getText();

            // Verifica se os campos não estão vazios
            if (nome.isEmpty() || genero.isEmpty() || autor.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos.");
                return;
            }

            // Cria um novo objeto Material
            Material material;
            if (codigoText.isEmpty()) {
                material = new Material(nome, genero, autor);
            } else {
                int codigo = Integer.parseInt(codigoText);
                material = new Material(codigo, nome, genero, autor);
            }

            // Chama o método cadastrar do DAO
            DAO dao = new DAO();
            if (dao.cadastrarMaterial(material)) {
                JOptionPane.showMessageDialog(null, "Material adicionado com sucesso!");
                // Atualizar a lista de cadastros após a adição
                buscarMateriais();
                CatalogoMaterial tela = new CatalogoMaterial();
                tela.setLocationRelativeTo(null);
                tela.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "Erro ao adicionar material.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "O código deve ser um número inteiro válido.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Problemas técnicos. Tente novamente mais tarde.");
            e.printStackTrace();
        } finally {
            // Desabilitar campos e reverter texto do botão para "Novo"
            novoMaterialButton.setText("Novo");

            novo = true;
        }
    }
    }//GEN-LAST:event_novoMaterialButtonActionPerformed

    private void atualizarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atualizarButtonActionPerformed
        int escolha = JOptionPane.showConfirmDialog(null, "Atualizar material?");
    if (escolha == JOptionPane.YES_OPTION) {
        try {
            int codigo = Integer.parseInt(codigoField.getText());
            String nome = nameField.getText();
            String genero = generoField.getText();
            String autor = autorField.getText();
            
            Material material = new Material(codigo, nome, genero, autor);
            
            DAO dao = new DAO();
            dao.atualizarMaterial(material);
            JOptionPane.showMessageDialog(null, "Material atualizado com sucesso");
            buscarMateriais();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Falha técnica. Tente novamente mais tarde.");
            e.printStackTrace();
        }
    }
    }//GEN-LAST:event_atualizarButtonActionPerformed

    private Material materialSelecionado;
    private DAO dao = new DAO();
       
    private void removerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removerButtonActionPerformed
       if (materialSelecionado == null) {
        // Primeiro clique
        materialSelecionado = (Material) materialComboBox.getSelectedItem();
        removerButton.setText("Confirmar");
    } else {
        // Segundo clique
        Material materialAtual = (Material) materialComboBox.getSelectedItem();
        if (materialSelecionado != null && materialSelecionado.equals(materialAtual)) {
            // Remover material selecionado
            if (dao.removerMaterial(materialSelecionado)) {
                JOptionPane.showMessageDialog(null, "Material removido com sucesso!");
                try {
                    // Atualizar a lista de materiais após a remoção
                    buscarMateriais();
                } catch (Exception ex) {
                    Logger.getLogger(DashboardMaterial.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Erro ao remover material.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Selecione um material para remover.");
        }
        // Resetar o material selecionado e o texto do botão
        materialSelecionado = null;
        removerButton.setText("Remover");
    }
    }//GEN-LAST:event_removerButtonActionPerformed

    private void removerMaterial(Material material) {
    // Implemente a lógica para remover o material, por exemplo:
    // DAO dao = new DAO();
    // dao.removerMaterial(material);
    // Atualizar a lista de materiais, se necessário
    // buscarMateriais();
}
    
    private void cancelarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarButtonActionPerformed
    // Desabilitar os campos textuais e limpar seus conteúdos
    nameField.setText("");
    generoField.setText("");
    autorField.setText("");
    nameField.setEditable(false);
    generoField.setEditable(false);
    autorField.setEditable(false);
    
    // Resetar o texto dos botões "Novo Material" e "Remover Material"
    novoMaterialButton.setText("Novo");
    removerButton.setText("Remover");
    
    // Desabilitar os botões "Novo Material" e "Remover Material"
    novoMaterialButton.setEnabled(true);
    removerButton.setEnabled(true);
    }//GEN-LAST:event_cancelarButtonActionPerformed

    private void sairButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairButtonActionPerformed
        this.dispose(); 
    }//GEN-LAST:event_sairButtonActionPerformed

    private void materialComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_materialComboBoxActionPerformed
    Material material = (Material) materialComboBox.getSelectedItem();
if (material != null) {
    codigoField.setText(Integer.toString(material.getCodigo())); // Convert integer to String
    nameField.setText(material.getNome());
    generoField.setText(material.getGenero());
    autorField.setText(material.getAutor());
} else {
    // Trate o caso em que cadastro é nulo, se necessário
    // Por exemplo, exiba uma mensagem de erro ou faça outra ação adequada
}
    }//GEN-LAST:event_materialComboBoxActionPerformed

    private void nameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameFieldActionPerformed
        setLocationRelativeTo(null);
    }//GEN-LAST:event_nameFieldActionPerformed

    private void generoFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generoFieldActionPerformed
        setLocationRelativeTo(null);
    }//GEN-LAST:event_generoFieldActionPerformed

    private void autorFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_autorFieldActionPerformed
        setLocationRelativeTo(null);
    }//GEN-LAST:event_autorFieldActionPerformed

    private void listaAtalhoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listaAtalhoButtonActionPerformed
        CatalogoMaterial tela = new CatalogoMaterial();
        tela.setLocationRelativeTo(null);
        tela.setVisible(true);
    }//GEN-LAST:event_listaAtalhoButtonActionPerformed

    private void nameFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nameFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            generoField.requestFocus();
        }
    }//GEN-LAST:event_nameFieldKeyPressed

    private void generoFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_generoFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            autorField.requestFocus();
        }
    }//GEN-LAST:event_generoFieldKeyPressed

    private void codigoFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codigoFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_codigoFieldActionPerformed

    private void codigoFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codigoFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            nameField.requestFocus();
        }
    }//GEN-LAST:event_codigoFieldKeyPressed
    

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DashboardMaterial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DashboardMaterial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DashboardMaterial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DashboardMaterial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new DashboardMaterial().setVisible(true);
                } catch (Exception ex) {
                    Logger.getLogger(DashboardMaterial.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton atualizarButton;
    private javax.swing.JTextField autorField;
    private javax.swing.JButton cancelarButton;
    private javax.swing.JTextField codigoField;
    private javax.swing.JTextField generoField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JButton listaAtalhoButton;
    private javax.swing.JComboBox<Material> materialComboBox;
    private javax.swing.JTextField nameField;
    private javax.swing.JButton novoMaterialButton;
    private javax.swing.JButton removerButton;
    private javax.swing.JButton sairButton;
    // End of variables declaration//GEN-END:variables
}
