package Classes;

public class Material {
    private int codigo;
    private String nome;
    private String genero;
    private String autor;

    // Construtor com o código
    public Material(int codigo, String nome, String genero, String autor) {
        this.codigo = codigo;
        this.nome = nome;
        this.genero = genero;
        this.autor = autor;
    }

    // Construtor sem o código
    public Material(String nome, String genero, String autor) {
        this.nome = nome;
        this.genero = genero;
        this.autor = autor;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    @Override
    public String toString() {
        return this.nome + " - " + this.autor;
    }
}
