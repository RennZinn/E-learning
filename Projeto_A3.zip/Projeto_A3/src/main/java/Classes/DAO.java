package Classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
public class DAO {
  
// CADASTRO
    
 public boolean existe(Usuario usuario) throws Exception {
        String sql = "SELECT * FROM CadastroUsuarios WHERE login = ? AND senha = ?";
        try (Connection c = ConexaoBD.obtemConexao();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, usuario.getLogin());
            ps.setString(2, usuario.getSenha());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public boolean existeUsuarioPorEmail(String email) throws Exception {
        String sql = "SELECT * FROM CadastroUsuarios WHERE email = ?";
        try (Connection c = ConexaoBD.obtemConexao();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public boolean existeUsuarioPorCpf(String cpf) throws Exception {
        String sql = "SELECT * FROM CadastroUsuarios WHERE cpf = ?";
        try (Connection c = ConexaoBD.obtemConexao();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, cpf);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }
    public boolean existeUsuarioPorTelefone(String telefone) throws Exception {
        String sql = "SELECT * FROM CadastroUsuarios WHERE telefone = ?";
        try (Connection c = ConexaoBD.obtemConexao();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, telefone);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public boolean existeUsuarioPorLogin(String login) throws Exception {
        String sql = "SELECT * FROM CadastroUsuarios WHERE login = ?";
        try (Connection c = ConexaoBD.obtemConexao();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, login);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public boolean cadastrar(Cadastro cadastro) throws Exception {
        String sql = "INSERT INTO CadastroUsuarios (nome, email, endereco, cpf, telefone, login, senha) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = ConexaoBD.obtemConexao();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, cadastro.getNome());
            ps.setString(2, cadastro.getEmail());
            ps.setString(3, cadastro.getEndereco());
            ps.setString(4, cadastro.getCpf());
            ps.setString(5, cadastro.getTelefone());
            ps.setString(6, cadastro.getLogin());
            ps.setString(7, cadastro.getSenha());
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0; // Retorna true se o cadastro foi bem-sucedido
        }
}
 public boolean removerCadastro(Cadastro cadastro) {
    String sql = "DELETE FROM CadastroUsuarios WHERE codigo = ? AND nome = ? AND email = ? AND endereco = ? AND cpf = ? AND telefone = ? AND login = ? AND senha = ?";

    try (Connection conn = ConexaoBD.obtemConexao();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, cadastro.getCodigo());
        ps.setString(2, cadastro.getNome());
        ps.setString(3, cadastro.getEmail());
        ps.setString(4, cadastro.getEndereco());
        ps.setString(5, cadastro.getCpf());
        ps.setString(6, cadastro.getTelefone());
        ps.setString(7, cadastro.getLogin());
        ps.setString(8, cadastro.getSenha());
        int rowsAffected = ps.executeUpdate();
        return rowsAffected > 0;
    } catch (Exception e) {
        System.err.println("Erro ao remover usuário do banco de dados: " + e.getMessage());
        return false;
    }
 }
public void atualizarCadastro(Cadastro cadastro) throws Exception {
    String sql = "UPDATE CadastroUsuarios SET nome = ?, email = ?, endereco = ?, cpf = ?, telefone = ?, login = ?, senha = ? WHERE codigo = ?";
    try (Connection conexao = ConexaoBD.obtemConexao();
         PreparedStatement ps = conexao.prepareStatement(sql)) {

        ps.setString(1, cadastro.getNome());
        ps.setString(2, cadastro.getEmail());
        ps.setString(3, cadastro.getEndereco());
        ps.setString(4, cadastro.getCpf());
        ps.setString(5, cadastro.getTelefone());
        ps.setString(6, cadastro.getLogin());
        ps.setString(7, cadastro.getSenha());
        ps.setInt(8, cadastro.getCodigo());

        int linhasAfetadas = ps.executeUpdate();
        if (linhasAfetadas > 0) {
            System.out.println("Cadastro atualizado com sucesso.");
        } else {
            System.out.println("Nenhuma linha afetada. Verifique se o código do usuário é válido.");
        }
    }
}
    public ArrayList<Cadastro> obterCadastro() throws Exception {
    String sql = "SELECT * FROM CadastroUsuarios";
    try (Connection conn = ConexaoBD.obtemConexao();
         PreparedStatement ps = conn.prepareStatement(sql,
                 ResultSet.TYPE_SCROLL_INSENSITIVE,
                 ResultSet.CONCUR_READ_ONLY);
         ResultSet rs = ps.executeQuery()) {

        ArrayList<Cadastro> cadastros = new ArrayList<>();
        while (rs.next()) {
            int codigo = rs.getInt("codigo");
            String nome = rs.getString("nome");
            String email = rs.getString("email");
            String endereco = rs.getString("endereco");
            String cpf = rs.getString("cpf");
            String telefone = rs.getString("telefone");
            String login = rs.getString("login");
            String senha = rs.getString("senha");
            cadastros.add(new Cadastro(codigo, nome, email, endereco, cpf, telefone, login, senha));
        }
        return cadastros;
    } catch (Exception e) {
        // Handle the exception appropriately, e.g., log it or throw a custom exception
        throw new Exception("Error fetching data from database", e);
    }
}
  
// MATERIAL

 public boolean cadastrarMaterial(Material cadastro) throws Exception {
    String sql = "INSERT INTO CadastroMaterial (nome, genero, autor) VALUES (?, ?, ?)";
    try (Connection c = ConexaoBD.obtemConexao();
         PreparedStatement ps = c.prepareStatement(sql)) {
        ps.setString(1, cadastro.getNome());
        ps.setString(2, cadastro.getGenero());
        ps.setString(3, cadastro.getAutor());
        int rowsAffected = ps.executeUpdate();
        return rowsAffected > 0; // Retorna true se o cadastro foi bem-sucedido
    }
 }
 public boolean removerMaterial(Material material) {
    String sql = "DELETE FROM CadastroMaterial WHERE nome = ? AND genero = ? AND autor = ?";
    try (Connection conn = ConexaoBD.obtemConexao();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, material.getNome());
        ps.setString(2, material.getGenero());
        ps.setString(3, material.getAutor());
        int rowsAffected = ps.executeUpdate();
        return rowsAffected > 0;
    } catch (Exception e) {
        System.err.println("Erro ao remover material do banco de dados: " + e.getMessage());
        return false;
    }
}
public void atualizarMaterial (Material material) throws Exception{
 String sql = "UPDATE CadastroMaterial SET nome = ?, genero = ?, autor = ? WHERE codigo = ?";
    try (Connection conexao = ConexaoBD.obtemConexao();
         PreparedStatement ps = conexao.prepareStatement(sql)) {

        ps.setString(1, material.getNome());
        ps.setString(2, material.getGenero());
        ps.setString(3, material.getAutor());
        ps.setInt(4, material.getCodigo());

        int linhasAfetadas = ps.executeUpdate();
        if (linhasAfetadas > 0) {
            System.out.println("Material atualizado com sucesso.");
        } else {
            System.out.println("Nenhuma linha afetada. Verifique se o código do material é válido.");
        }
    }
 } 
 public Material[] obterMateriais() throws Exception {
    String sql = "SELECT * FROM CadastroMaterial";
    try (Connection conn = ConexaoBD.obtemConexao();
         PreparedStatement ps = conn.prepareStatement(sql,
                 ResultSet.TYPE_SCROLL_INSENSITIVE,
                 ResultSet.CONCUR_READ_ONLY);
         ResultSet rs = ps.executeQuery()) {

        int totalDeMateriais = rs.last() ? rs.getRow() : 0;

        Material[] materiais = new Material[totalDeMateriais];
        rs.beforeFirst();
        int contador = 0;
        while (rs.next()) {
            int codigo = rs.getInt("codigo");
            String nome = rs.getString("nome");
            String genero = rs.getString("genero");
            String autor = rs.getString("autor");
            materiais[contador++] = new Material(codigo, nome, genero, autor);
        }
        return materiais; // Retornar o array de materiais preenchido
    }
 }

// AULAS

    public boolean cadastrarAula(Aulas aula) throws Exception {
    String sql = "INSERT INTO Aula (nomeProf, Materia, Conteudo, Link) VALUES (?, ?, ?, ?)";
    try (Connection c = ConexaoBD.obtemConexao();
         PreparedStatement ps = c.prepareStatement(sql)) {
        ps.setString(1, aula.getNomeProf());
        ps.setString(2, aula.getMateria());
        ps.setString(3, aula.getConteudo());
          ps.setString(4, aula.getLink());
        int rowsAffected = ps.executeUpdate();
        return rowsAffected > 0; // Retorna true se o cadastro foi bem-sucedido
    }
}
    public boolean removerAula(Aulas aula) {
    String sql = "DELETE FROM Aula WHERE nomeProf = ? AND Materia = ? AND Conteudo = ? AND Link = ?";
    try (Connection conn = ConexaoBD.obtemConexao();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, aula.getNomeProf());
        ps.setString(2, aula.getMateria());
        ps.setString(3, aula.getConteudo());
          ps.setString(4, aula.getLink());
        int rowsAffected = ps.executeUpdate();
        return rowsAffected > 0;
    } catch (Exception e) {
        System.err.println("Erro ao remover video do banco de dados: " + e.getMessage());
        return false;
    }
}
    public void atualizarAula (Aulas aula) throws Exception{
 String sql = "UPDATE Aula SET nomeProf = ?, materia = ?, conteudo = ?, link = ? WHERE codigo = ?";
    try (Connection conexao = ConexaoBD.obtemConexao();
         PreparedStatement ps = conexao.prepareStatement(sql)) {

        ps.setString(1, aula.getNomeProf());
        ps.setString(2, aula.getMateria());
        ps.setString(3, aula.getConteudo());
        ps.setString(4, aula.getLink());
        ps.setInt(5, aula.getCodigo());

        int linhasAfetadas = ps.executeUpdate();
        if (linhasAfetadas > 0) {
            System.out.println("Aula atualizada com sucesso.");
        } else {
            System.out.println("Nenhuma linha afetada. Verifique se o código do material é válido.");
        }
    }
 }
public Aulas[] obterAulas() throws Exception {
    Aulas[] aula;
    String sql = "SELECT * FROM Aula";
    try (Connection conn = ConexaoBD.obtemConexao();
         PreparedStatement ps = conn.prepareStatement(sql,
                 ResultSet.TYPE_SCROLL_INSENSITIVE,
                 ResultSet.CONCUR_READ_ONLY);
         ResultSet rs = ps.executeQuery()) {

        int totalDeAulas = rs.last() ? rs.getRow() : 0;

        aula = new Aulas[totalDeAulas];
        rs.beforeFirst();
        int contador = 0;
        while (rs.next()) {
            int codigo = rs.getInt("codigo");
            String nomeProf = rs.getString("nomeProf");
            String Materia = rs.getString("Materia");
            String Conteudo = rs.getString("Conteudo");
            String Link = rs.getString("Link");
            aula[contador++] = new Aulas(codigo, nomeProf, Materia, Conteudo, Link);
        }
    }
    return aula;
}   
}