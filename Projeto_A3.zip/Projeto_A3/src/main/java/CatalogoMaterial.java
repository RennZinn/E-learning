import Classes.DAO;
import Classes.Material;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public final class CatalogoMaterial extends javax.swing.JFrame {
    private DAO dao;
    
    public CatalogoMaterial() {
        initComponents();
        dao = new DAO();
        configurarFiltros();
        atualizarTabelaMaterial();
        int red = 0;
        int green = 80;
        int blue = 117;
        Color customColor = new Color(red, green, blue);

        // Mudando a cor de fundo do content pane
        getContentPane().setBackground(customColor);
    }
    private void configurarFiltros() {
        generoComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                atualizarTabelaMaterial();
            }
        });

        autorComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                atualizarTabelaMaterial();
            }
        });
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        materialTable = new javax.swing.JTable();
        voltarButton = new javax.swing.JButton();
        generoComboBox = new javax.swing.JComboBox<>();
        autorComboBox = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setFont(new java.awt.Font("SF Pro", 0, 10)); // NOI18N
        setMinimumSize(new java.awt.Dimension(650, 650));

        materialTable.setBackground(new java.awt.Color(120, 120, 120));
        materialTable.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        materialTable.setForeground(new java.awt.Color(255, 255, 255));
        materialTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Nome", "Gênero", "Autor"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        materialTable.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        materialTable.setGridColor(new java.awt.Color(120, 120, 120));
        materialTable.setPreferredSize(new java.awt.Dimension(650, 650));
        materialTable.setSelectionBackground(new java.awt.Color(90, 90, 90));
        materialTable.setSelectionForeground(new java.awt.Color(204, 204, 204));
        materialTable.setShowGrid(true);
        materialTable.setUpdateSelectionOnSort(false);
        materialTable.setVerifyInputWhenFocusTarget(false);
        jScrollPane1.setViewportView(materialTable);
        if (materialTable.getColumnModel().getColumnCount() > 0) {
            materialTable.getColumnModel().getColumn(0).setResizable(false);
            materialTable.getColumnModel().getColumn(1).setPreferredWidth(400);
            materialTable.getColumnModel().getColumn(2).setPreferredWidth(120);
            materialTable.getColumnModel().getColumn(3).setPreferredWidth(200);
        }

        voltarButton.setBackground(new java.awt.Color(114, 114, 114));
        voltarButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        voltarButton.setForeground(new java.awt.Color(255, 255, 255));
        voltarButton.setText("Voltar");
        voltarButton.setAlignmentX(0.5F);
        voltarButton.setBorderPainted(false);
        voltarButton.setContentAreaFilled(false);
        voltarButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        voltarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarButtonActionPerformed(evt);
            }
        });

        generoComboBox.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        generoComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mostrar tudo", "Economia", "Biologia", "Matemática", "Química", "Psicologia", "Física", "História", "Sociologia", "Administração", "Estatística", "Filosofia", "Programação", "Contabilidade", "Direito", "Geografia", "Medicina", "Marketing", "Educação" }));
        generoComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generoComboBoxActionPerformed(evt);
            }
        });

        autorComboBox.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        autorComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mostrar tudo", "N. Gregory Mankiw", "Bruce Alberts", "James Stewart", "Peter Atkins", "David G. Myers", "David Halliday e Robert Resnick", "Boris Fausto", "Rosângela Lunardelli Cavallazzi", "Antonio Cesar Amaru Maximiano", "Wilton de Oliveira Bussab e Pedro Alberto Morettin", "Paulo Ghiraldelli Jr.", "André Backes", "José Carlos Marion", "Pedro Lenza", "A. C. Costa", "Eustáquio de Sene", "Arthur C. Guyton e John E. Hall", "Philip Kotler", "José Carlos Libâneo", "Hal R. Varian", "David J. Griffiths" }));
        autorComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                autorComboBoxActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Gênero:");

        jLabel2.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Autor:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(generoComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(autorComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(voltarButton))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(generoComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(autorComboBox, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 525, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(voltarButton)
                .addContainerGap(42, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(666, 658));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void voltarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarButtonActionPerformed
      this.dispose();
    }//GEN-LAST:event_voltarButtonActionPerformed

    private void generoComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generoComboBoxActionPerformed
     atualizarTabelaMaterial();
    }//GEN-LAST:event_generoComboBoxActionPerformed

    private void autorComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_autorComboBoxActionPerformed
     atualizarTabelaMaterial();
    }//GEN-LAST:event_autorComboBoxActionPerformed
    public void atualizarTabelaMaterial() {
        try {
            Material[] materiais = dao.obterMateriais();

            DefaultTableModel modelo = (DefaultTableModel) materialTable.getModel();
            modelo.setRowCount(0);

            List<Material> materiaisFiltrados = filtrarMateriais(materiais);
            preencherTabela(materiaisFiltrados);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Materiais indisponíveis, tente novamente mais tarde.");
            e.printStackTrace();
        }
    }
private List<Material> filtrarMateriais(Material[] materiais) {
    String generoSelecionado = (String) generoComboBox.getSelectedItem();
    String autorSelecionado = (String) autorComboBox.getSelectedItem();

    List<Material> materiaisFiltrados = new ArrayList<>(Arrays.asList(materiais));

if (!"Mostrar tudo".equals(generoSelecionado) && generoSelecionado != null && !generoSelecionado.isEmpty()) {
    materiaisFiltrados.removeIf(material -> !material.getGenero().equals(generoSelecionado));
}

if (!"Mostrar tudo".equals(autorSelecionado) && autorSelecionado != null && !autorSelecionado.isEmpty()) {
    materiaisFiltrados.removeIf(material -> !material.getAutor().equals(autorSelecionado));
}

    return materiaisFiltrados;
}
    private void preencherTabela(List<Material> materiais) {
        DefaultTableModel modelo = (DefaultTableModel) materialTable.getModel();
        for (Material material : materiais) {
            Object[] rowData = { material.getCodigo(), material.getNome(), material.getGenero(), material.getAutor() };
            modelo.addRow(rowData);
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CatalogoMaterial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CatalogoMaterial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CatalogoMaterial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CatalogoMaterial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                CatalogoMaterial catalogo = new CatalogoMaterial();
                catalogo.setVisible(true);
}

        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> autorComboBox;
    private javax.swing.JComboBox<String> generoComboBox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable materialTable;
    private javax.swing.JButton voltarButton;
    // End of variables declaration//GEN-END:variables
}
