import Classes.Cadastro;
import Classes.DAO;
import java.awt.Color;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class CatalogoUsuarios extends javax.swing.JFrame {

    public CatalogoUsuarios() {
        initComponents();
        atualizarTabelaUsuarios();
        int red = 0;
        int green = 80;
        int blue = 117;
        Color customColor = new Color(red, green, blue);

        // Mudando a cor de fundo do content pane
        getContentPane().setBackground(customColor);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        usuariosTable = new javax.swing.JTable();
        sairButton = new javax.swing.JButton();
        gerenciarAtalhoButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        usuariosTable.setBackground(new java.awt.Color(120, 120, 120));
        usuariosTable.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        usuariosTable.setForeground(new java.awt.Color(255, 255, 255));
        usuariosTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Código", "Nome", "Email", "Endereço", "CPF", "Telefone", "Login", "Senha"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        usuariosTable.setGridColor(new java.awt.Color(120, 120, 120));
        usuariosTable.setSelectionBackground(new java.awt.Color(90, 90, 90));
        usuariosTable.setSelectionForeground(new java.awt.Color(204, 204, 204));
        jScrollPane1.setViewportView(usuariosTable);

        sairButton.setBackground(new java.awt.Color(114, 114, 114));
        sairButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        sairButton.setForeground(new java.awt.Color(255, 255, 255));
        sairButton.setText("Voltar");
        sairButton.setAlignmentX(0.5F);
        sairButton.setBorderPainted(false);
        sairButton.setContentAreaFilled(false);
        sairButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        sairButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairButtonActionPerformed(evt);
            }
        });

        gerenciarAtalhoButton4.setBackground(new java.awt.Color(204, 204, 204));
        gerenciarAtalhoButton4.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        gerenciarAtalhoButton4.setForeground(new java.awt.Color(204, 204, 204));
        gerenciarAtalhoButton4.setText("Clique aqui para gerenciar os usuários");
        gerenciarAtalhoButton4.setAlignmentX(0.5F);
        gerenciarAtalhoButton4.setBorderPainted(false);
        gerenciarAtalhoButton4.setContentAreaFilled(false);
        gerenciarAtalhoButton4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        gerenciarAtalhoButton4.setMaximumSize(new java.awt.Dimension(76, 22));
        gerenciarAtalhoButton4.setMinimumSize(new java.awt.Dimension(76, 22));
        gerenciarAtalhoButton4.setPreferredSize(new java.awt.Dimension(76, 22));
        gerenciarAtalhoButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gerenciarAtalhoButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(188, Short.MAX_VALUE)
                .addComponent(gerenciarAtalhoButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(125, 125, 125)
                .addComponent(sairButton))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 603, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sairButton)
                    .addComponent(gerenciarAtalhoButton4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16))
        );

        setSize(new java.awt.Dimension(666, 658));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void gerenciarAtalhoButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gerenciarAtalhoButton4ActionPerformed
        try {
            DashboardUsuarios tela = new DashboardUsuarios();
            tela.setLocationRelativeTo(null);
            tela.setVisible(true);
        } catch (Exception ex) {
            Logger.getLogger(CatalogoUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_gerenciarAtalhoButton4ActionPerformed

    private void sairButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairButtonActionPerformed
        this.dispose();
    }//GEN-LAST:event_sairButtonActionPerformed

     public void atualizarTabelaUsuarios() {
    try {
        DAO dao = new DAO();
        ArrayList<Cadastro> cadastros = dao.obterCadastro(); // Corrigido para cadastros
        
        // Obtendo o modelo da tabela existente
        DefaultTableModel modelo = (DefaultTableModel) usuariosTable.getModel();
        
        // Limpando os dados existentes da tabela
        modelo.setRowCount(0);
        
        // Preenchendo a tabela com os dados dos cadastros
        for (Cadastro cadastro : cadastros) { // Corrigido para cadastros
            Object[] rowData = {cadastro.getCodigo(), cadastro.getNome(), cadastro.getEmail(), cadastro.getEndereco(),cadastro.getCpf(), cadastro.getTelefone(), cadastro.getLogin(), cadastro.getSenha()};
            modelo.addRow(rowData);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Cadastros indisponíveis, tente novamente mais tarde.");
        e.printStackTrace();
    }
}

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CatalogoUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CatalogoUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CatalogoUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CatalogoUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CatalogoUsuarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton gerenciarAtalhoButton4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton sairButton;
    private javax.swing.JTable usuariosTable;
    // End of variables declaration//GEN-END:variables
}
