import Classes.DAO;
import Classes.Cadastro;
import java.awt.Color;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

public class TelaCadastro extends javax.swing.JFrame {
    public TelaCadastro() {
        initComponents();
        
        // Definindo uma cor personalizada com valores RGB
        int red = 0;
        int green = 80;
        int blue = 117;
        Color customColor = new Color(red, green, blue);

        // Mudando a cor de fundo do content pane
        getContentPane().setBackground(customColor);
    }
        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nameField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        loginField = new javax.swing.JTextField();
        cpfField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        loginAtalhoButton = new javax.swing.JButton();
        mostrarSenha = new javax.swing.JCheckBox();
        cadastroButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        phoneField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        sairButton = new javax.swing.JButton();
        emailField = new javax.swing.JTextField();
        adressField = new javax.swing.JTextField();
        passwordField = new javax.swing.JPasswordField();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        codigoField = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cadastro");
        setMinimumSize(new java.awt.Dimension(600, 600));

        nameField.setBackground(new java.awt.Color(255, 255, 255));
        nameField.setFont(new java.awt.Font("SF Pro", 0, 18)); // NOI18N
        nameField.setForeground(new java.awt.Color(0, 0, 0));
        nameField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        nameField.setMargin(new java.awt.Insets(5, 2, 5, 2));
        nameField.setMaximumSize(new java.awt.Dimension(300, 40));
        nameField.setMinimumSize(new java.awt.Dimension(300, 40));
        nameField.setPreferredSize(new java.awt.Dimension(300, 40));
        nameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameFieldActionPerformed(evt);
            }
        });
        nameField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nameFieldKeyPressed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Endereço*");

        loginField.setBackground(new java.awt.Color(255, 255, 255));
        loginField.setFont(new java.awt.Font("SF Pro", 0, 18)); // NOI18N
        loginField.setForeground(new java.awt.Color(0, 0, 0));
        loginField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        loginField.setMargin(new java.awt.Insets(5, 2, 5, 2));
        loginField.setMaximumSize(new java.awt.Dimension(300, 40));
        loginField.setMinimumSize(new java.awt.Dimension(300, 40));
        loginField.setPreferredSize(new java.awt.Dimension(300, 40));
        loginField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginFieldActionPerformed(evt);
            }
        });
        loginField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                loginFieldKeyPressed(evt);
            }
        });

        cpfField.setBackground(new java.awt.Color(255, 255, 255));
        cpfField.setFont(new java.awt.Font("SF Pro", 0, 18)); // NOI18N
        cpfField.setForeground(new java.awt.Color(0, 0, 0));
        cpfField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        cpfField.setMargin(new java.awt.Insets(5, 2, 5, 2));
        cpfField.setMaximumSize(new java.awt.Dimension(300, 40));
        cpfField.setMinimumSize(new java.awt.Dimension(300, 40));
        cpfField.setPreferredSize(new java.awt.Dimension(300, 40));
        cpfField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cpfFieldActionPerformed(evt);
            }
        });
        cpfField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cpfFieldKeyPressed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("CPF*");

        loginAtalhoButton.setBackground(new java.awt.Color(204, 204, 204));
        loginAtalhoButton.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        loginAtalhoButton.setForeground(new java.awt.Color(204, 204, 204));
        loginAtalhoButton.setText("Já tem uma conta? Faça login");
        loginAtalhoButton.setAlignmentX(0.5F);
        loginAtalhoButton.setBorderPainted(false);
        loginAtalhoButton.setContentAreaFilled(false);
        loginAtalhoButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        loginAtalhoButton.setMaximumSize(new java.awt.Dimension(76, 22));
        loginAtalhoButton.setMinimumSize(new java.awt.Dimension(76, 22));
        loginAtalhoButton.setPreferredSize(new java.awt.Dimension(76, 22));
        loginAtalhoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginAtalhoButtonActionPerformed(evt);
            }
        });

        mostrarSenha.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        mostrarSenha.setForeground(new java.awt.Color(255, 255, 255));
        mostrarSenha.setText("Mostrar a senha");
        mostrarSenha.setBorder(null);
        mostrarSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarSenhaActionPerformed(evt);
            }
        });

        cadastroButton.setBackground(new java.awt.Color(114, 114, 114));
        cadastroButton.setFont(new java.awt.Font("SF Pro", 1, 14)); // NOI18N
        cadastroButton.setForeground(new java.awt.Color(255, 255, 255));
        cadastroButton.setText("Cadastrar");
        cadastroButton.setAlignmentX(0.5F);
        cadastroButton.setBorderPainted(false);
        cadastroButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        cadastroButton.setMaximumSize(new java.awt.Dimension(76, 22));
        cadastroButton.setMinimumSize(new java.awt.Dimension(76, 22));
        cadastroButton.setPreferredSize(new java.awt.Dimension(76, 22));
        cadastroButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastroButtonActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nome*");

        phoneField.setBackground(new java.awt.Color(255, 255, 255));
        phoneField.setFont(new java.awt.Font("SF Pro", 0, 18)); // NOI18N
        phoneField.setForeground(new java.awt.Color(0, 0, 0));
        phoneField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        phoneField.setMargin(new java.awt.Insets(5, 2, 5, 2));
        phoneField.setMaximumSize(new java.awt.Dimension(300, 40));
        phoneField.setMinimumSize(new java.awt.Dimension(300, 40));
        phoneField.setPreferredSize(new java.awt.Dimension(300, 40));
        phoneField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneFieldActionPerformed(evt);
            }
        });
        phoneField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                phoneFieldKeyPressed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Senha*");

        sairButton.setBackground(new java.awt.Color(114, 114, 114));
        sairButton.setFont(new java.awt.Font("SF Pro", 0, 16)); // NOI18N
        sairButton.setForeground(new java.awt.Color(255, 255, 255));
        sairButton.setText("Voltar");
        sairButton.setBorderPainted(false);
        sairButton.setContentAreaFilled(false);
        sairButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        sairButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairButtonActionPerformed(evt);
            }
        });

        emailField.setBackground(new java.awt.Color(255, 255, 255));
        emailField.setFont(new java.awt.Font("SF Pro", 0, 18)); // NOI18N
        emailField.setForeground(new java.awt.Color(0, 0, 0));
        emailField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        emailField.setMargin(new java.awt.Insets(5, 2, 5, 2));
        emailField.setMaximumSize(new java.awt.Dimension(300, 40));
        emailField.setMinimumSize(new java.awt.Dimension(300, 40));
        emailField.setPreferredSize(new java.awt.Dimension(300, 40));
        emailField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailFieldActionPerformed(evt);
            }
        });
        emailField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                emailFieldKeyPressed(evt);
            }
        });

        adressField.setBackground(new java.awt.Color(255, 255, 255));
        adressField.setFont(new java.awt.Font("SF Pro", 0, 18)); // NOI18N
        adressField.setForeground(new java.awt.Color(0, 0, 0));
        adressField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        adressField.setMargin(new java.awt.Insets(5, 2, 5, 2));
        adressField.setMaximumSize(new java.awt.Dimension(300, 40));
        adressField.setMinimumSize(new java.awt.Dimension(300, 40));
        adressField.setPreferredSize(new java.awt.Dimension(300, 40));
        adressField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adressFieldActionPerformed(evt);
            }
        });
        adressField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                adressFieldKeyPressed(evt);
            }
        });

        passwordField.setBackground(new java.awt.Color(255, 255, 255));
        passwordField.setFont(new java.awt.Font("SF Pro", 0, 18)); // NOI18N
        passwordField.setForeground(new java.awt.Color(0, 0, 0));
        passwordField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        passwordField.setMargin(new java.awt.Insets(5, 2, 5, 2));
        passwordField.setMaximumSize(new java.awt.Dimension(300, 40));
        passwordField.setMinimumSize(new java.awt.Dimension(300, 40));
        passwordField.setPreferredSize(new java.awt.Dimension(300, 40));
        passwordField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordFieldActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Telefone*");

        jLabel3.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Email*");

        jLabel7.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Login*");

        codigoField.setEditable(false);
        codigoField.setBackground(new java.awt.Color(255, 255, 255));
        codigoField.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        codigoField.setForeground(new java.awt.Color(0, 0, 0));
        codigoField.setActionCommand("<Not Set>");
        codigoField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        codigoField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codigoFieldActionPerformed(evt);
            }
        });
        codigoField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                codigoFieldKeyPressed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Código");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(171, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(codigoField)
                        .addComponent(loginField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(mostrarSenha, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(passwordField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(phoneField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(cpfField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(adressField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(emailField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(nameField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(cadastroButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(loginAtalhoButton, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(101, 101, 101)
                        .addComponent(sairButton)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(codigoField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(emailField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(adressField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cpfField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(phoneField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(loginField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(mostrarSenha)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cadastroButton, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(loginAtalhoButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sairButton))
                .addGap(12, 12, 12))
        );

        setSize(new java.awt.Dimension(666, 658));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void loginAtalhoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginAtalhoButtonActionPerformed
        TelaLogin tela = new TelaLogin();
        tela.setLocationRelativeTo(null);
        tela.setVisible(true);
    }//GEN-LAST:event_loginAtalhoButtonActionPerformed

    private void cadastroButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastroButtonActionPerformed
    String codigoText = codigoField.getText();
    String nome = nameField.getText();
    String email = emailField.getText();
    String endereco = adressField.getText();
    String cpf = cpfField.getText();
    String telefone = phoneField.getText();
    String login = loginField.getText();
    String senha = new String(passwordField.getPassword());

    try {
        DAO dao = new DAO();

        if (dao.existeUsuarioPorEmail(email)) {
            JOptionPane.showMessageDialog(null, "Erro: Email já cadastrado.");
            return;
        }

        if (dao.existeUsuarioPorCpf(cpf)) {
            JOptionPane.showMessageDialog(null, "Erro: CPF já cadastrado.");
            return;
        }

        if (dao.existeUsuarioPorLogin(login)) {
            JOptionPane.showMessageDialog(null, "Erro: Login já cadastrado.");
            return;
        }

        if (dao.existeUsuarioPorTelefone(telefone)) {
            JOptionPane.showMessageDialog(null, "Erro: Telefone já cadastrado.");
            return;
        }

        Cadastro cadastro;
        if (codigoText.isEmpty()) {
            cadastro = new Cadastro(nome, email, endereco, cpf, telefone, login, senha);
        } else {
            int codigo = Integer.parseInt(codigoText);
            cadastro = new Cadastro(codigo, nome, email, endereco, cpf, telefone, login, senha);
        }

        if (dao.cadastrar(cadastro)) {
            JOptionPane.showMessageDialog(null, "Cadastro bem-sucedido!\n Bem vindo, " + cadastro.getLogin() + "!");
            TelaLogin tela = new TelaLogin();
            tela.setLocationRelativeTo(null);
            tela.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Usuário inválido.");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Problemas técnicos. Tente novamente mais tarde.");
        e.printStackTrace();
    }
    }//GEN-LAST:event_cadastroButtonActionPerformed

    private void sairButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairButtonActionPerformed
        this.dispose(); // TODO add your handling code here:
    }//GEN-LAST:event_sairButtonActionPerformed

    private void mostrarSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mostrarSenhaActionPerformed
        if(mostrarSenha.isSelected()) {
            passwordField.setEchoChar((char)0);
        } else {
            passwordField.setEchoChar('*');
        }
    }//GEN-LAST:event_mostrarSenhaActionPerformed

    private void passwordFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordFieldActionPerformed

    }//GEN-LAST:event_passwordFieldActionPerformed

    private void loginFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginFieldActionPerformed
        this.setLocationRelativeTo(null);
    }//GEN-LAST:event_loginFieldActionPerformed

    private void phoneFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phoneFieldActionPerformed
        this.setLocationRelativeTo(null);
    }//GEN-LAST:event_phoneFieldActionPerformed

    private void cpfFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cpfFieldActionPerformed
        this.setLocationRelativeTo(null);
    }//GEN-LAST:event_cpfFieldActionPerformed

    private void adressFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adressFieldActionPerformed
        this.setLocationRelativeTo(null);
    }//GEN-LAST:event_adressFieldActionPerformed

    private void emailFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailFieldActionPerformed
        this.setLocationRelativeTo(null);
    }//GEN-LAST:event_emailFieldActionPerformed

    private void nameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameFieldActionPerformed
        this.setLocationRelativeTo(null);
    }//GEN-LAST:event_nameFieldActionPerformed

    private void nameFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nameFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            emailField.requestFocus();
        }
    }//GEN-LAST:event_nameFieldKeyPressed

    private void emailFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_emailFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            adressField.requestFocus();
         }   
    }//GEN-LAST:event_emailFieldKeyPressed

    private void adressFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_adressFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            cpfField.requestFocus();
            }
    }//GEN-LAST:event_adressFieldKeyPressed

    private void cpfFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cpfFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            phoneField.requestFocus();
            }
    }//GEN-LAST:event_cpfFieldKeyPressed

    private void phoneFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_phoneFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            loginField.requestFocus();
            }
    }//GEN-LAST:event_phoneFieldKeyPressed

    private void loginFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_loginFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            passwordField.requestFocus();
            }
    }//GEN-LAST:event_loginFieldKeyPressed

    private void codigoFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codigoFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_codigoFieldActionPerformed

    private void codigoFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codigoFieldKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_codigoFieldKeyPressed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadastro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField adressField;
    private javax.swing.JButton cadastroButton;
    private javax.swing.JTextField codigoField;
    private javax.swing.JTextField cpfField;
    private javax.swing.JTextField emailField;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JButton loginAtalhoButton;
    private javax.swing.JTextField loginField;
    private javax.swing.JCheckBox mostrarSenha;
    private javax.swing.JTextField nameField;
    private javax.swing.JPasswordField passwordField;
    private javax.swing.JTextField phoneField;
    private javax.swing.JButton sairButton;
    // End of variables declaration//GEN-END:variables
}
