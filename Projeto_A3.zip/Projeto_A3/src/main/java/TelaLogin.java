import Classes.DAO;
import Classes.Usuario;
import java.awt.Color;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

public class TelaLogin extends javax.swing.JFrame {
    private static int tentativas = 0;

    public TelaLogin() {
        initComponents();
        setLocationRelativeTo(null);
        
        // Definindo uma cor personalizada com valores RGB
        int red = 0;
        int green = 80;
        int blue = 117;
        Color customColor = new Color(red, green, blue);

        // Mudando a cor de fundo do content pane
        getContentPane().setBackground(customColor);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        loginField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        passwordField = new javax.swing.JPasswordField();
        mostrarSenha = new javax.swing.JCheckBox();
        loginButton = new javax.swing.JButton();
        sairButton = new javax.swing.JButton();
        cadastroAtalhoButton = new javax.swing.JButton();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Login");
        setName("Login"); // NOI18N

        jLabel2.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Login");

        loginField.setColumns(1);
        loginField.setFont(new java.awt.Font("SF Pro", 0, 20)); // NOI18N
        loginField.setToolTipText("");
        loginField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        loginField.setMargin(new java.awt.Insets(5, 3, 5, 3));
        loginField.setMaximumSize(new java.awt.Dimension(270, 54));
        loginField.setMinimumSize(new java.awt.Dimension(270, 54));
        loginField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginFieldActionPerformed(evt);
            }
        });
        loginField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                loginFieldKeyPressed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Senha");

        passwordField.setFont(new java.awt.Font("SF Pro", 0, 20)); // NOI18N
        passwordField.setToolTipText("");
        passwordField.setAlignmentX(1.0F);
        passwordField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        passwordField.setCaretColor(new java.awt.Color(255, 255, 255));
        passwordField.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        passwordField.setMargin(new java.awt.Insets(5, 3, 5, 3));
        passwordField.setMaximumSize(new java.awt.Dimension(270, 54));
        passwordField.setMinimumSize(new java.awt.Dimension(270, 54));
        passwordField.setName(""); // NOI18N
        passwordField.setPreferredSize(new java.awt.Dimension(270, 54));
        passwordField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordFieldActionPerformed(evt);
            }
        });

        mostrarSenha.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        mostrarSenha.setForeground(new java.awt.Color(210, 210, 210));
        mostrarSenha.setText("Mostrar a senha");
        mostrarSenha.setBorder(null);
        mostrarSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarSenhaActionPerformed(evt);
            }
        });

        loginButton.setBackground(new java.awt.Color(114, 114, 114));
        loginButton.setFont(new java.awt.Font("SF Pro", 1, 14)); // NOI18N
        loginButton.setForeground(new java.awt.Color(255, 255, 255));
        loginButton.setText("Login");
        loginButton.setAlignmentX(0.5F);
        loginButton.setBorderPainted(false);
        loginButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        loginButton.setMaximumSize(new java.awt.Dimension(76, 22));
        loginButton.setMinimumSize(new java.awt.Dimension(76, 22));
        loginButton.setPreferredSize(new java.awt.Dimension(76, 22));
        loginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginButtonActionPerformed(evt);
            }
        });

        sairButton.setBackground(new java.awt.Color(114, 114, 114));
        sairButton.setFont(new java.awt.Font("SF Pro", 0, 14)); // NOI18N
        sairButton.setForeground(new java.awt.Color(255, 255, 255));
        sairButton.setText("Voltar");
        sairButton.setAlignmentX(0.5F);
        sairButton.setBorderPainted(false);
        sairButton.setContentAreaFilled(false);
        sairButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        sairButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairButtonActionPerformed(evt);
            }
        });

        cadastroAtalhoButton.setBackground(new java.awt.Color(204, 204, 204));
        cadastroAtalhoButton.setFont(new java.awt.Font("SF Pro", 0, 12)); // NOI18N
        cadastroAtalhoButton.setForeground(new java.awt.Color(204, 204, 204));
        cadastroAtalhoButton.setText("Não tem uma conta? Cadastre-se");
        cadastroAtalhoButton.setAlignmentX(0.5F);
        cadastroAtalhoButton.setBorderPainted(false);
        cadastroAtalhoButton.setContentAreaFilled(false);
        cadastroAtalhoButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        cadastroAtalhoButton.setMaximumSize(new java.awt.Dimension(76, 22));
        cadastroAtalhoButton.setMinimumSize(new java.awt.Dimension(76, 22));
        cadastroAtalhoButton.setPreferredSize(new java.awt.Dimension(76, 22));
        cadastroAtalhoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastroAtalhoButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(180, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                        .addComponent(loginField, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cadastroAtalhoButton, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(mostrarSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(loginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(168, 168, 168))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(sairButton))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(171, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(loginField, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(4, 4, 4)
                .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(mostrarSenha)
                .addGap(18, 18, 18)
                .addComponent(loginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(79, 79, 79)
                .addComponent(cadastroAtalhoButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(91, 91, 91)
                .addComponent(sairButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        passwordField.getAccessibleContext().setAccessibleName("");

        setSize(new java.awt.Dimension(666, 658));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void loginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginButtonActionPerformed
        if (tentativas >= 3) {
        JOptionPane.showMessageDialog(null, "Número máximo de tentativas excedido. O programa será encerrado.");
        System.exit(0);
    }
    String login = loginField.getText();
    String senha = new String(passwordField.getPassword());
    try {
        Usuario usuario = new Usuario(login, senha);
        DAO dao = new DAO();
        if (dao.existe(usuario)) {
            JOptionPane.showMessageDialog(null, "Bem vindo, " + usuario.getLogin() + "!");
            MenuPlataforma tela = new MenuPlataforma();
            tela.setLocationRelativeTo(null);
            tela.setVisible(true);
        } else {
            tentativas++;
            JOptionPane.showMessageDialog(null, "Usuário inválido. Tentativas restantes: " + (3 - tentativas));
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Problemas técnicos. Tente novamente mais tarde.");
        e.printStackTrace();
    }
    }//GEN-LAST:event_loginButtonActionPerformed

    private void cadastroAtalhoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastroAtalhoButtonActionPerformed
        TelaCadastro tela = new TelaCadastro();
        tela.setLocationRelativeTo(null);
        tela.setVisible(true);
    }//GEN-LAST:event_cadastroAtalhoButtonActionPerformed

    private void mostrarSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mostrarSenhaActionPerformed
        if(mostrarSenha.isSelected()) {
            passwordField.setEchoChar((char)0);
        } else {
            passwordField.setEchoChar('*');
        }
    }//GEN-LAST:event_mostrarSenhaActionPerformed

    private void passwordFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordFieldActionPerformed

    private void sairButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairButtonActionPerformed
        tentativas = 0;
        this.dispose();
    }//GEN-LAST:event_sairButtonActionPerformed

    private void loginFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_loginFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            passwordField.requestFocus();
        }
    }//GEN-LAST:event_loginFieldKeyPressed

    private void loginFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginFieldActionPerformed
        this.setLocationRelativeTo(null);
    }//GEN-LAST:event_loginFieldActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cadastroAtalhoButton;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton loginButton;
    private javax.swing.JTextField loginField;
    private javax.swing.JCheckBox mostrarSenha;
    private javax.swing.JPasswordField passwordField;
    private javax.swing.JButton sairButton;
    // End of variables declaration//GEN-END:variables
}
